#pragma once
#include "Actor.h"
#include <string>
#include <memory>

constexpr int IMG_SIZE_X = 600;
constexpr int IMG_SIZE_Y = 200;

class AffineTransformation;

class Player : public Actor
{
public:
	Player(VECTOR2 posLeft, VECTOR2 posRight, OYAKO oyako, int playerNumber);

	~Player();

	void Update();
	void Draw();
	void ValueComparison();
	void TurnNext();

	const int& GetNumber();
	const int& GetFingerNumber();
	const int& GetFingerValue();

	const bool& GetNextFlag();

private:

	struct Finger
	{
		OYAKO _oyako;

		VECTOR2 posLeft;//�����̍��W
		VECTOR2 posRight;//�E���̍��W

		int _playerNumber = 0;//��ڲ԰�̎��ʔԍ�
		int _number = 0;//������w�̐�

		int _setValue = 0;//�w�̑����̗\�z
		int _nowNumber = 2;//���݂̎w�̐�

		float _pushCount = 0;
		int w, h;

		float _size = 1.0f;
		float _angle = 1.0f;
		float _z = 0.0f;
	};

	Finger _finger;
	Finger _thumbL; // ��
	Finger _thumbR; // �E
	bool _nextFlag = false;
	bool _changeFlag = false;
	int _waitTime = 0;

	int _handle = 0;// ���̉摜
	float _count;		// �w�h�炵�p
	int softImage;

	int _countOya = 0;
	float _alpha;


	std::shared_ptr<AffineTransformation> _mat;
	vector<VECTOR2>v;
};

