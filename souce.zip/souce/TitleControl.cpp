#include "DxLib.h"
#include "GameTask.h"
#include "TitleControl.h"
#include "ImageMng.h"
#include "KeyMng.h"
#include <cmath>

#define _USE_MATH_DEFINES

constexpr int HAND_IMG_SIZE_X = 28;
constexpr int HAND_IMG_SIZE_Y = 28;

int TitleControl::_handPosCntX = 0;
int TitleControl::_handPosCntY = 5;

int TitleControl::_instanceCnt = 0;

bool TitleControl::_removeFlag = false;
bool TitleControl::_modeFlag = false;

TitleControl::TitleControl()
{
	if (_instanceCnt % HAND_VALUE_X == 0 && _instanceCnt != 0)
	{
		_handPosCntX = 0;
	}

	ch._pos.x = HAND_INTERVAL_X * _handPosCntX;
	ch._pos.y = -HAND_IMG_SIZE_Y;

	_instanceCnt++;
	_handPosCntX++;
	
	// ������
	b._UL.x = SCREEN_CENTER_X - 145;
	b._UL.y = (SCREEN_SIZE_Y - 100) - 50;
	b._DR.x = SCREEN_CENTER_X + 145;
	b._DR.y = (SCREEN_SIZE_Y - 100) + 50;
}

TitleControl::~TitleControl()
{
	_instanceCnt--;
}

void TitleControl::Update()
{
	ch._angle = 45;
	ch._speed = 3.0f;
	ch._theta = ch._angle * (PI / 180.0f);

	// 45�x�����ɉ�]�A�ړ�
	ch._pos.x -= ch._speed * sin(ch._theta);
	ch._pos.y += ch._speed * cos(ch._theta);
	ch._size = 2.5f;

	if (ch._pos.y - ((HAND_IMG_SIZE_Y / 2) * ch._size) > SCREEN_SIZE_Y)
	{
		_removeFlag = true;
	}
	GetMousePoint(&m._posX, &m._posY);

}

void TitleControl::Draw()
{
	DrawRotaGraph(ch._pos.x, ch._pos.y, ch._size, ch._theta, IMAGE_ID("image/GJ_hand.png"), true);
	DrawFormatString(10, 50, 0x000000, "instanceCnt:%d", _instanceCnt);

	if (b._UL.x < m._posX && b._UL.y < m._posY && b._DR.x > m._posX && b._DR.y > m._posY)
	{
		b._scale = 1.0f;
		if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0)
		{
			_modeFlag = true;
		}
	}
	else
	{
		b._scale = 0.7f;
	}

	

	if (lpGameTask.GetButtonFlag())
	{
		b._scale = 1.0f;

		if (KeyMng::GetInstance().trgKey[P1_SPACE])
		{
			_modeFlag = true;
		}

	}
	else
	{
		b._scale = 0.7f;
	}

	DrawRotaGraph(SCREEN_CENTER_X, SCREEN_SIZE_Y - 100, b._scale, 0, IMAGE_ID("image/start.png"), true);
}

