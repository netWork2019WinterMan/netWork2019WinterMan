#include "ClientState.h"

ClientState::ClientState()
{
	active = ((NetHandle = ConnectNetWork(Ip, PotNum)) != -1 ? true : false);
	if (active)
	{
		state = NetState::READY;
	}
	else
	{
		state = NetState::NON;
	}
	mes.push_front(DrawMes::CLIENT_CREATE);
}

bool ClientState::CheckNetWork(void)
{
	if (GetLostNetWork() != -1)
	{
		// �ײ��Ă̏ꍇ�́A��Ԃ�ر����
		CloseNetWork();
		mes.push_front(DrawMes::DIS_CONNECT);
		return false;
	}
	if (state < NetState::READY)
	{
		return false;
	}
	return true;
}

bool ClientState::CloseNetWork(void)
{
	DxLib::CloseNetWork(NetHandle);
	state = NetState::NON;
	return true;
}

// EOF