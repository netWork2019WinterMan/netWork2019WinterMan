#include "NetWorkState.h"

NetWorkState::NetWorkState()
{
	// �ð���ω�����ү����
	mes_string[static_cast<int>(DrawMes::HOST_CREATE)] = "Complete to HOST Create !! Waiting to Connect...";
	mes_string[static_cast<int>(DrawMes::HOST_CANT_CREATE)] = "Can't Complete to HOST Create...";
	mes_string[static_cast<int>(DrawMes::CLIENT_CONNECT)] = "Client Connect!!";
	mes_string[static_cast<int>(DrawMes::CLIENT_CREATE)] = "Complete to Connect to Host";
	mes_string[static_cast<int>(DrawMes::CLIENT_CANT_CREATE)] = "Can't Complete to Connect to Host...";
	mes_string[static_cast<int>(DrawMes::DIS_CONNECT)] = "Warning!!! DisConnect";
	mes_string[static_cast<int>(DrawMes::SEND_MESSAGE)] = "Send Message.";
	mes_string[static_cast<int>(DrawMes::RECEIVE_MESSAGE)] = "Receive Message.";
}

bool NetWorkState::Update(void)
{
	if (!CheckNetWork())
	{
		return false;
	}
	if (revData.mode == mesType::NON)
	{
		// ���������o���������O���Ŏ��o���ċ�ɂȂ��Ă���΁A��������
		if (GetNetWorkDataLength(NetHandle) >= sizeof(strSendMes))
		{
			// �ēx�ޯ̧�����܂��Ă���ꍇ��������
			strSendMes r_mes;
			NetWorkRecv(NetHandle, &r_mes, sizeof(strSendMes));
			mes.push_front(DrawMes::RECEIVE_MESSAGE);
			if (r_mes.mode == mesType::GAME_START)
			{
				if (state == NetState::READY)
				{
					sendMes.push_back({ mesType::GAME_START,0,0,0 });
				}
				state = NetState::ACTIVE;
			}
			else if (r_mes.mode == mesType::AGAIN)
			{
				sendMes.push_back(lastMes);
				strSendMes nextMes{ mesType::NON,0,0,0 };
				while (NetWorkRecvToPeek(NetHandle, &nextMes, sizeof(strSendMes)))
				{
					if (nextMes.mode != mesType::AGAIN)
					{
						break;
					}
					// ���̍đ��M���A�����Ă���ꍇ�͓ǂݎ̂Ă�
					NetWorkRecv(NetHandle, &r_mes, sizeof(strSendMes));
				}
			}
			else
			{
				revData = r_mes;
			}
		}
	}
	for (auto itr = sendMes.begin(); itr != sendMes.end();)
	{
		NetWorkSend(NetHandle, &(*itr), sizeof(strSendMes));
		lastMes = *itr;
		itr = sendMes.erase(itr);
		mes.push_front(DrawMes::SEND_MESSAGE);
	}
	return true;
}

bool NetWorkState::SetSendMes(strSendMes mes)
{
	sendMes.push_back(mes);
	return true;
}

strSendMes NetWorkState::GetData(void)
{
	auto s_data = revData;
	revData = { mesType::NON,0,0,0 };
	return s_data;
}


void NetWorkState::Draw(void)
{
	DrawBox(0, 560, 800, 600, 0x202020, true);

	if (!mes.size())
	{
		return;
	}

	auto mes_id = mes.begin();

	DrawFormatString(10, 565, 0xffffff, mes_string[static_cast<int>(*mes_id)].c_str());

}

// EOF