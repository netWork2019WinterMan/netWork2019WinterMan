#pragma once
#include <string>
#include <vector>
#include <memory>

class TitleControl;
class ControlSelectMode;
class ControlGameResult;
class Actor;

#define  lpGameTask GameTask::GetInstance()

using namespace std;

constexpr int SCREEN_SIZE_X = 960;
constexpr int SCREEN_SIZE_Y = 540;
constexpr int SCREEN_CENTER_X = SCREEN_SIZE_X / 2;
constexpr int SCREEN_CENTER_Y = SCREEN_SIZE_Y / 2;
constexpr float PI = 3.141592;

constexpr int LEFT_PLAYER_NUM_ARROW_LEFT_X = 10;
constexpr int LEFT_PLAYER_NUM_ARROW_LEFT_Y = SCREEN_CENTER_Y + 5;
constexpr int LEFT_PLAYER_NUM_ARROW_DOWN_X = 25;
constexpr int LEFT_PLAYER_NUM_ARROW_DOWN_Y = SCREEN_CENTER_Y - 5;
constexpr int LEFT_PLAYER_NUM_ARROW_UP_X = 25;
constexpr int LEFT_PLAYER_NUM_ARROW_UP_Y = SCREEN_CENTER_Y + 15;

constexpr int RIGHT_PLAYER_NUM_ARROW_RIGHT_X = SCREEN_CENTER_X - 80;
constexpr int RIGHT_PLAYER_NUM_ARROW_RIGHT_Y = SCREEN_CENTER_Y + 5;
constexpr int RIGHT_PLAYER_NUM_ARROW_DOWN_X = SCREEN_CENTER_X - 95;
constexpr int RIGHT_PLAYER_NUM_ARROW_DOWN_Y = SCREEN_CENTER_Y - 5;
constexpr int RIGHT_PLAYER_NUM_ARROW_UP_X = SCREEN_CENTER_X - 95;
constexpr int RIGHT_PLAYER_NUM_ARROW_UP_Y = SCREEN_CENTER_Y + 15;

constexpr int UP_DIFFICULT_ARROW_DOWN_X = SCREEN_SIZE_X - 150;
constexpr int UP_DIFFICULT_ARROW_DOWN_Y = SCREEN_CENTER_Y - 70;
constexpr int UP_DIFFICULT_ARROW_LEFT_X = SCREEN_SIZE_X - 160;
constexpr int UP_DIFFICULT_ARROW_LEFT_Y = SCREEN_CENTER_Y - 50;
constexpr int UP_DIFFICULT_ARROW_RIGHT_X = SCREEN_SIZE_X - 140;
constexpr int UP_DIFFICULT_ARROW_RIGHT_Y = SCREEN_CENTER_Y - 50;

constexpr int DOWN_DIFFICULT_ARROW_UP_X = SCREEN_SIZE_X - 150;
constexpr int DOWN_DIFFICULT_ARROW_UP_Y = SCREEN_CENTER_Y + 70;
constexpr int DOWN_DIFFICULT_ARROW_LEFT_X = SCREEN_SIZE_X - 160;
constexpr int DOWN_DIFFICULT_ARROW_LEFT_Y = SCREEN_CENTER_Y + 50;
constexpr int DOWN_DIFFICULT_ARROW_RIGHT_X = SCREEN_SIZE_X - 140;
constexpr int DOWN_DIFFICULT_ARROW_RIGHT_Y = SCREEN_CENTER_Y + 50;


enum G_MODE {
	G_INIT,
	G_TITLE,
	G_SELECT_MODE,
	G_SELECT_ROOM,
	G_RULE,
	G_PVP,
	G_MAIN,
	G_RESULT,
	G_MAX
};

struct Rule
{
	int _x, _y;
	int _nowPlayerNum = 0;
	int _playerMax = 2; //�l��
	int difficulty = 0; //��Փx
};

struct Arrow
{
	float _arrowSizeL = 0.0f;
	float _arrowSizeR = 0.0f;
	float _arrowSizeU = 0.0f;
	float _arrowSizeD = 0.0f;
};

class GameTask
{
public:
	// �ݸ����
	static void Create(void);
	static GameTask &GetInstance(void)
	{
		Create();
		return *s_Instance;
	}

	int GetCreateTimer() { return _createTimer; }
	const int& GetButtonFlag() { return _buttonFlag; }

	void SetMoveAnimationFlag(bool _setAnim) { this->_setAnim = _setAnim; }
	const bool& GetMoveAnimationFlag() { return _setAnim; }

	int SystemInit();		// �V�X�e��������
	void GameUpdate();		// �Q�[�����[�v
	void GameInit();		// �Q�[�����e�̐���ϐ��ȂǏ�����
	void GameTitle();		// �^�C�g��
	void GameSelectMode();	// ���[�h�I��
	void GameSelectRoom();	// ���[���I��(PvP�̂�)
	void GameRule();		// ���[���ݒ�
	void GameNetWork();
	void GameMain();		// �Q�[����
	void GameMainToResult();
	void GameResult();		// ���U���g�\��(�����L���O��)
	
private:
	static GameTask *s_Instance;

	void (GameTask::*gMode[G_MAX])() = { &GameTask::GameInit,&GameTask::GameTitle,&GameTask::GameSelectMode,
		&GameTask::GameSelectRoom,& GameTask::GameRule, &GameTask::GameNetWork, &GameTask::GameMain,&GameTask::GameResult };		// �Q�[�����[�h�J�ڗp

	//--------------------------------------------------
	// �ϐ��Q
	//--------------------------------------------------

	Rule _rule;
	Arrow _ar;

	// STL
	vector<shared_ptr<TitleControl>>tc;
	vector<shared_ptr<ControlSelectMode>>csm;
	vector<shared_ptr<ControlGameResult>>cgr;
	
	// ��ԑJ�ڗp
	int _currentMode = -1;		// ���݂̃��[�h
	int _oldMode = -1;			// ��O�̃��[�h
	int _futureMode = -1;		// ���U���g���_�Ői�݂������[�h
	int _handRemove = false;
	int _createTimer = 0;
	int _buttonFlag = false;

	int _num[11];
	int _BGM, _DECISION;

	bool _setAnim;
	int timer = 0;

	int _netWorkCnt = 0;
	bool ClickFlag = false;
};

