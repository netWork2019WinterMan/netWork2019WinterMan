#include "Player.h"
#include "KeyMng.h"
#include "DxLib.h"
#include "ImageMng.h"
#include "AffineTransformation.h"
#include "GameTask.h"
#include <cmath>

Player::Player(VECTOR2 posLeft, VECTOR2 posRight, OYAKO oyako, int playerNumber)
{
	_finger._pushCount = 0;
	_finger._oyako = oyako;
	_finger._playerNumber = playerNumber;
	_finger.posLeft = posLeft;
	_finger.posRight = posRight;
	_handle = IMAGE_ID("image/leftHand.png");
	_finger.w = 256, _finger.h = 256;

	_thumbL.posLeft = VECTOR2(_finger.posLeft.x + 110, _finger.posLeft.y + 20, 1);
	_thumbR.posRight = VECTOR2(_finger.posRight.x + 80, _finger.posRight.y + 20, 1);

	_thumbL.w = 65, _thumbL.h = 140;
	_thumbR.w = 65, _thumbR.h = 140;

	_mat = std::make_shared<AffineTransformation>(_thumbL.posLeft);

	_count = 0;
}

Player::~Player()
{
}

void Player::Update()
{

	if (_changeFlag)
	{
		return;
	}

	_nextFlag = false;
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	if (GameMain::GetInstance().GetStopMotion())
	{
		return;
	}
	if (_finger._playerNumber == nextNumber && _finger._nowNumber <= 0)
	{
		TurnNext();
		return;
	}
	if (GameMain::GetInstance().GetNextNumber() == _finger._playerNumber)
	{
		if (_finger._pushCount >= MAX_TIME - 10)
		{
			_nextFlag = true;

		}

		//��
		float stickL = KeyMng::GetInstance().input.ThumbLY;
		auto stickLMax = static_cast<float>(50.0f / 32767);
		stickL *= stickLMax;
		float addCount = stickL;

		float angleL = KeyMng::GetInstance().input.ThumbLY;
		auto angleLMax = static_cast<float>(-10.0f / 32767);
		angleL *= angleLMax;
		auto angle = angleL;

		float sizeL = KeyMng::GetInstance().input.ThumbLY;
		auto sizeLMax = static_cast<float>(6.0f / 32767);
		sizeL *= sizeLMax;
		auto size = sizeL + 1.0f;


		if (stickL > 1)
		{
			_thumbL._number = 1;
			(_finger._pushCount < MAX_TIME ? _finger._pushCount = stickL : 0);
			if (_thumbL._number > 0)
			{
				(_thumbL._angle > -10.0f ? _thumbL._angle = angle : 0);
				(_thumbL._size < 6.0f ? _thumbL._size = size : 0);
			}
		}
		else
		{
			_thumbL._number = 0;
			(_thumbL._angle < 0 ? _thumbL._angle = angle : 0);
			(_thumbL._size > 1.0f ? _thumbL._size = size : 0);
		}

		//�E
		float stickR = KeyMng::GetInstance().input.ThumbRY;
		auto stickRMax = static_cast<float>(50.0f / 32767);
		stickR *= stickRMax;
		float addCountR = stickR;

		float angleR = KeyMng::GetInstance().input.ThumbRY;
		auto angleRMax = static_cast<float>(-10.0f / 32767);
		angleR *= angleRMax;
		auto angleRValue = angleR;

		float sizeR = KeyMng::GetInstance().input.ThumbRY;
		auto sizeRMax = static_cast<float>(6.0f / 32767);
		sizeR *= sizeRMax;
		auto sizeRValue = sizeR + 1.0f;


		if (stickR > 1)
		{
			_thumbR._number = 1;
			(_finger._pushCount < MAX_TIME ? _finger._pushCount = stickR : 0);
			if (_thumbR._number > 0)
			{
				(_thumbR._angle > -10.0f ? _thumbR._angle = angleRValue : 0);
				(_thumbR._size < 6.0f ? _thumbR._size = sizeRValue : 0);
			}
		}
		else
		{
			_thumbR._number = 0;
			(_thumbR._angle < 0 ? _thumbR._angle = angleRValue : 0);
			(_thumbR._size > 1.0f ? _thumbR._size = sizeRValue : 0);
		}

		if (stickL < -1 && stickR < -1)
		{
			(_finger._pushCount < MAX_TIME ? _finger._pushCount = -(stickL + stickR) : 0);


		}
		if (_finger._pushCount < 5)
		{
			_finger._pushCount = 0;
		}

		if (KeyMng::GetInstance().trgKey[P1_Y])
		{
			(_finger._setValue < GameMain::GetInstance().GetFingerValue() ? _finger._setValue++ : 0);
		}
		else if (KeyMng::GetInstance().trgKey[P1_X])
		{
			(_finger._setValue > 0 ? _finger._setValue-- : 0);
		}
	}

	_finger._number = _thumbL._number + _thumbR._number;

}

void Player::Draw()
{
	auto posValue = [&](const VECTOR2& pos, const float& angle) {
		VECTOR2 p;
		p = _mat->Rotation(VECTOR2(1.0f, pos.y, pos.z), angle);
		p.x = pos.x;
		return p;
	};
	auto& nextNumber = GameMain::GetInstance().GetNextNumber();

	_mat->SetPos(_thumbL.posLeft);
	//���e�w����
	auto leftUp = VECTOR2(_thumbL.posLeft.x, _thumbL.posLeft.y, _thumbL.posLeft.z);
	auto rightUp = VECTOR2(_thumbL.posLeft.x + _thumbL.w, _thumbL.posLeft.y, _thumbL.posLeft.z);
	auto rightDown = VECTOR2(_thumbL.posLeft.x + _thumbL.w, _thumbL.posLeft.y + _thumbL.h, _thumbL.posLeft.z);
	auto leftDown = VECTOR2(_thumbL.posLeft.x, _thumbL.posLeft.y + _thumbL.h, _thumbL.posLeft.z);

	leftUp = posValue(leftUp, _thumbL._angle);
	rightUp = posValue(rightUp, _thumbL._angle);
	rightDown = posValue(rightDown, _thumbL._angle);
	leftDown = posValue(leftDown, _thumbL._angle);
	;
	_count++;
	//����sa
	DrawModiGraph(_finger.posLeft.x - sin(PI * 2 / 300 * _count) * 5.0f, _finger.posLeft.y - sin(PI * 2 / 300 * _count) * 5.0f,
		_finger.posLeft.x + _finger.w - sin(PI * 2 / 300 * _count) * 5.0f, _finger.posLeft.y - sin(PI * 2 / 300 * _count) * 5.0f,
		_finger.posLeft.x + _finger.w - sin(PI * 2 / 300 * _count) * 5.0f, _finger.posLeft.y + _finger.h - sin(PI * 2 / 300 * _count) * 5.0f,
		_finger.posLeft.x, _finger.posLeft.y + _finger.h, IMAGE_ID("image/leftHand.png"), true);

	DrawModiGraph(leftUp.x - (2 * _thumbL._size) + (_thumbL._angle * 2) - sin(PI * 2 / 300 * _count) * 5.0f, leftUp.y - (2 * _thumbL._size) - sin(PI * 2 / 300 * _count) * 5.0f,
		rightUp.x + (2 * _thumbL._size) + (_thumbL._angle * 2) - sin(PI * 2 / 300 * _count) * 5.0f, rightUp.y - (2 * _thumbL._size) - sin(PI * 2 / 300 * _count) * 5.0f,
		rightDown.x - sin(PI * 2 / 300 * _count) * 5.0f, rightDown.y - sin(PI * 2 / 300 * _count) * 5.0f,
		leftDown.x - sin(PI * 2 / 300 * _count) * 5.0f, leftDown.y - sin(PI * 2 / 300 * _count) * 5.0f, IMAGE_ID("image/leftFinger.png"), true);

	_mat->SetPos(_thumbR.posRight);

	//�E��
	leftUp = VECTOR2(_thumbR.posRight.x, _thumbR.posRight.y, _thumbR.posRight.z);
	rightUp = VECTOR2(_thumbR.posRight.x + _thumbR.w, _thumbR.posRight.y, _thumbR.posRight.z);
	rightDown = VECTOR2(_thumbR.posRight.x + _thumbR.w, _thumbR.posRight.y + _thumbR.h, _thumbR.posRight.z);
	leftDown = VECTOR2(_thumbR.posRight.x, _thumbR.posRight.y + _thumbR.h, _thumbR.posRight.z);

	if (_thumbR._number > 0)
	{
		leftUp = posValue(leftUp, _thumbR._angle);
		rightUp = posValue(rightUp, _thumbR._angle);
		rightDown = posValue(rightDown, _thumbR._angle);
		leftDown = posValue(leftDown, _thumbR._angle);

		leftUp = VECTOR2(leftUp.x - (2 * _thumbR._size) - (_thumbR._angle * 2), leftUp.y - (2 * _thumbR._size));
		rightUp = VECTOR2(rightUp.x + (2 * _thumbR._size) - (_thumbR._angle * 2), rightUp.y - (2 * _thumbR._size));
	}


	DrawModiGraph(_finger.posRight.x - sin(PI * 2 / 300 * _count) * 5.0f, _finger.posRight.y - sin(PI * 2 / 300 * _count) * 5.0f + _finger._fadeout,
		_finger.posRight.x + _finger.w - sin(PI * 2 / 300 * _count) * 5.0f, _finger.posRight.y - sin(PI * 2 / 300 * _count) * 5.0f + _finger._fadeout,
		_finger.posRight.x + _finger.w - sin(PI * 2 / 300 * _count) * 5.0f, _finger.posRight.y + _finger.h - sin(PI * 2 / 300 * _count) * 5.0f + _finger._fadeout,
		_finger.posRight.x - sin(PI * 2 / 300 * _count) * 5.0f, _finger.posRight.y + _finger.h - sin(PI * 2 / 300 * _count) * 5.0f + _finger._fadeout, IMAGE_ID("image/rightHand.png"), true);

	DrawModiGraph(leftUp.x - sin(PI * 2 / 300 * _count) * 5.0f, leftUp.y - sin(PI * 2 / 300 * _count) * 5.0f + _finger._fadeout,
		rightUp.x - sin(PI * 2 / 300 * _count) * 5.0f, rightUp.y - sin(PI * 2 / 300 * _count) * 5.0f + _finger._fadeout,
		rightDown.x - sin(PI * 2 / 300 * _count) * 5.0f, rightDown.y - sin(PI * 2 / 300 * _count) * 5.0f + _finger._fadeout,
		leftDown.x - sin(PI * 2 / 300 * _count) * 5.0f, leftDown.y - sin(PI * 2 / 300 * _count) * 5.0f + _finger._fadeout, IMAGE_ID("image/rightFinger.png"), true);
	if (_finger._nowNumber <= 1)
	{
		_finger._fadeout += 5.0f;
	}

		if (_finger._playerNumber == nextNumber)
		{
			DrawBox(95 + (50 * nextNumber), 245, 130 + (50 * nextNumber), 305, 0xff0000, true);
			DrawFormatString(100 + (50 * nextNumber), 200, 0x000000, "%d", _finger._setValue);
			DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - _finger._pushCount, 0x00ffff, true);
			DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - MAX_TIME, 0x000000, false);
		}
	DrawBox(100 + (50 * _finger._playerNumber), 250, 125 + (50 * _finger._playerNumber), 300, 0xffff00, true);

	DrawFormatString(100 + (50 * _finger._playerNumber), 230, 0x000000, "�w:%d", _finger._number);
	DrawFormatString(100 + (50 * _finger._playerNumber), 310, 0x000000, "��:%d", _finger._nowNumber);

	DrawFormatString(600, 400, 0x000000, "%d", nextNumber);

	_alpha = _finger._pushCount * 5;
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, _alpha);
	DrawRotaGraph(SCREEN_CENTER_X, 50, 0.7f, 0.0f, IMAGE_ID("image/kakegoe.png"), true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, _alpha);

	_countOya++;
	if ((_countOya / 50 % 2) == 0)
	{
		DrawRotaGraph(SCREEN_CENTER_X, 110, 0.6f, 0, IMAGE_ID("image/youOya.png"), true);
	}


}

void Player::ValueComparison()
{
	if (GetRand(2) == 0)
	{
		_waitTime++;
	}
	if ((KeyMng::GetInstance().trgKey[P1_ENTER] || _waitTime > 30) && _changeFlag)
	{
		KeyMng::GetInstance().trgKey[P1_ENTER] = false;
		_waitTime = 0;
		TurnNext();
	}
	/* �w�肵���w�̑����ƍ��v�l�������Ȃ�� */
	else if (_finger._nowNumber > 0 && !_changeFlag)
	{
		auto fingerValue = GameMain::GetInstance().GetNumberValue();

		if (_finger._setValue == fingerValue)
		{
			--_finger._nowNumber;

			if (_finger._nowNumber <= 0)
			{
				GameMain::GetInstance().SubPlayerNumber(1);
			}
		}
		_changeFlag = true;

	}

}

void Player::TurnNext()
{
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	GameMain::GetInstance().SetStopMotion(false);
	GameMain::GetInstance().SetNextNumber((nextNumber >= GameMain::GetInstance().GetGameRule()._playerMax ? 1 :_finger._playerNumber + 1));
	_finger._setValue = 0;
	_finger._pushCount = 0;
	_changeFlag = false;
	//_number = 0;

}

void Player::ClearAngle()
{
}

const int& Player::GetNumber()
{
	return _finger._number;
}

const int& Player::GetFingerNumber()
{
	return _finger._nowNumber;
}

const int& Player::GetFingerValue()
{
	return _finger._setValue;
}

const bool& Player::GetNextFlag()
{
	return _nextFlag;
}
