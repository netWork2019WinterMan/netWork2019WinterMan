#include "CPU.h"
#include "KeyMng.h"
#include "ImageMng.h"
#include "DxLib.h"


CPU::CPU(OYAKO oyako, int playerNumber)
{
	_finger._oyako = oyako;
	_finger._playerNumber = playerNumber;

	_mat = std::make_shared<AffineTransformation>();
}

CPU::CPU()
{
}

CPU::~CPU()
{
}

void CPU::Update()
{

	if (_changeFlag || GameMain::GetInstance().GetNowPlayer() <= 1)
	{
		return;
	}

	if (GameMain::GetInstance().GetStopMotion())
	{
		return;
	}
	_nextFlag = false;
	auto nextNumber = GameMain::GetInstance().GetNextNumber();


	if (_finger._playerNumber == nextNumber && _finger._nowNumber <= 0)
	{
		TurnNext();
		return;
	}
	if (GameMain::GetInstance().GetNextNumber() == _finger._playerNumber)
	{
		int randomCount = GetRand(6);
		if (_finger._pushCount >= MAX_TIME)
		{
			_nextFlag = true;
		}
		if (randomCount <= 5)
		{
			if (_finger._number >= 1)
			{
				(_thumbR._pushCount < MAX_TIME ? _thumbR._pushCount++ : 0);
			}
			if (_finger._number >= 2)
			{
				(_thumbL._pushCount < MAX_TIME ? _thumbL._pushCount++ : 0);
			}
		}
		_finger._setValue = GetRand(GameMain::GetInstance().GetFingerValue());
	}
	int randomCount = GetRand(6);
	if (_finger._pushCount >= MAX_TIME)
	{
		_nextFlag = true;
	}
	/*if (randomCount <= 5)
	{
		(_thumbR._angle > -90.0f ? _thumbR._angle -= 2.0f : 0);
		(_thumbL._angle > -90.0f ? _thumbL._angle -= 2.0f : 0);

	}
	else
	{
		(_thumbR._pushCount > 0 ? _thumbR._pushCount-- : 0);
		(_thumbL._pushCount > 0 ? _thumbL._pushCount-- : 0);

		(_thumbR._angle < 0 ? _thumbR._angle += 2.0f : 0);
		(_thumbL._angle < 0 ? _thumbL._angle += 2.0f : 0);

	}*/
	if (_finger._nowNumber > 0)
	{
		_finger._number = GetRand(2);
	}
	else
	{
		_finger._number = 0;
	}
	_finger._pushCount = _thumbR._pushCount + _thumbL._pushCount;
}

void CPU::Draw()
{
	auto& nextNumber = GameMain::GetInstance().GetNextNumber();
	auto posValue = [&](const VECTOR2& pos, const float& angle) {
		VECTOR2 p;
		p = _mat->Rotation(VECTOR2(pos.x, pos.y, pos.z), angle);
		p.z = pos.z;
		return p;
	};
	

	if (_finger._playerNumber == nextNumber)
	{
		DrawBox(95 + (50 * nextNumber), 245, 130 + (50 * nextNumber), 305, 0xff0000, true);
		DrawFormatString(100 + (50 * nextNumber), 200, 0x000000, "%d", _finger._setValue);
		DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - _finger._pushCount, 0x00ffff, true);
		DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - MAX_TIME, 0x000000, false);
	}
	DrawBox(100 + (50 * _finger._playerNumber), 250, 125 + (50 * _finger._playerNumber), 300, 0xffff00, true);

	DrawFormatString(100 + (50 * _finger._playerNumber), 230, 0x000000, "�w:%d", _finger._number);
	DrawFormatString(100 + (50 * _finger._playerNumber), 310, 0x000000, "��:%d", _finger._nowNumber);

	DrawFormatString(600, 400, 0x000000, "%d", nextNumber);

	if (_finger._playerNumber == 3)
	{
		// �E�̓G
		// �E��
		_sinC._count1++;
		DrawRotaGraphF(SCREEN_SIZE_X - 100, SCREEN_CENTER_Y - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 3.5f, 0, IMAGE_ID("image/en_hand.png"), true);

		_thumbR._pos = VECTOR2(SCREEN_SIZE_X - 75, SCREEN_CENTER_Y - 17 - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 1);
		//_mat->SetPos(pos);
		//auto vec = posValue(pos, _finger._angle);
		DrawRotaGraphF(_thumbR._pos.x, _thumbR._pos.y, 3.5f, (-90 + (_thumbR._pushCount * 2)) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);


		// ����
		DrawRotaGraphF(SCREEN_SIZE_X - 70 + _finger._fadeout, SCREEN_CENTER_Y + 120 - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 4.2f, 0, IMAGE_ID("image/en_hand1.png"), true);

		_thumbL._pos = VECTOR2(SCREEN_SIZE_X - 41, SCREEN_CENTER_Y + 99 - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 1);

		DrawRotaGraphF(_thumbL._pos.x + _finger._fadeout, _thumbL._pos.y, 4.2f, (-90 + (_thumbL._pushCount * 2)) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);
		if (_finger._nowNumber <= 1)
		{
			_finger._fadeout += 5;
		}
		if (_sinC._count1 > 50)
		{
			_sinC._count2++;
		}
	}

	if (_finger._playerNumber == 4)
	{
		// ���̓G
		// �E��
		DrawRotaGraphF(100, SCREEN_CENTER_Y - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 3.5f, 0, IMAGE_ID("image/en_hand_miror.png"), true);
		DrawRotaGraphF(75, SCREEN_CENTER_Y - 17 - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 3.5f, ((90 - (_thumbR._pushCount * 2)) + _finger._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);
		
		
		// ����
		DrawRotaGraphF(70 + _finger._fadeout, SCREEN_CENTER_Y + 120 - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 4.2f, 0, IMAGE_ID("image/en_hand1_miror.png"), true);
		DrawRotaGraphF(41 + _finger._fadeout, SCREEN_CENTER_Y + 99 - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 4.2f, ((90 - (_thumbL._pushCount * 2)) + _finger._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);

		if (_finger._nowNumber <= 1)
		{
			_finger._fadeout-= 5;
		}
		if (_sinC._count2 > 100)
		{
			_sinC._count3++;
		}
	}

	if (_finger._playerNumber == 2)
	{
		// ��
		// �E��
		DrawRotaGraphF(SCREEN_CENTER_X - 40, SCREEN_CENTER_Y - 10 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, 3, 0, IMAGE_ID("image/en_handFront.png"), true);
		DrawRotaGraphF(SCREEN_CENTER_X - 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, 3, 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		DrawRotaGraphF(SCREEN_CENTER_X - 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f - (_thumbL._pushCount * 0.25f)*2, 3 + (_thumbL._pushCount * 0.02f), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		
		// ����
		DrawRotaGraphF(SCREEN_CENTER_X + 40, SCREEN_CENTER_Y - 10 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _finger._size), 0, IMAGE_ID("image/en_handFront_miror.png"), true);
		DrawRotaGraphF(SCREEN_CENTER_X + 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _finger._size), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);

		DrawRotaGraphF(SCREEN_CENTER_X + 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f - ((_thumbL._pushCount * 0.25f) * 2), (3 + _finger._size) + (_finger._size <= -3.0f ? 0 :(_thumbL._pushCount * 0.02f)), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);

		if(_finger._nowNumber <= 1)
		{
			(_finger._size > -3.0f ? _finger._size -= 0.1f : 0);
		}
	}
}

void CPU::ClearAngle()
{
	_thumbR._angle = 0.0f;
	_thumbL._angle = 0.0f;

	_thumbR._pushCount = 0;
	_thumbL._pushCount = 0;

}

void CPU::ValueComparison()
{
	if (GetRand(2) == 0)
	{
		_waitTime++;
	}
	if ((KeyMng::GetInstance().trgKey[P1_ENTER] || _waitTime > 60) && _changeFlag)
	{
		KeyMng::GetInstance().trgKey[P1_ENTER] = false;
		_waitTime = 0;
		TurnNext();
	}
	/* �w�肵���w�̑����ƍ��v�l�������Ȃ�� */
	else if (_finger._nowNumber > 0 && !_changeFlag)
	{
		auto fingerValue = GameMain::GetInstance().GetNumberValue();

		if (_finger._setValue == fingerValue)
		{
			--_finger._nowNumber;
			if (_finger._nowNumber <= 0)
			{
				GameMain::GetInstance().SubPlayerNumber(1);
			}
		}
		_changeFlag = true;

	}
}

void CPU::TurnNext()
{
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	GameMain::GetInstance().SetStopMotion(false);
	GameMain::GetInstance().SetNextNumber((nextNumber >= GameMain::GetInstance().GetGameRule()._playerMax ? 1 : _finger._playerNumber + 1));
	GameMain::GetInstance().SetAngleReset(true);
	_finger._setValue = 0;
	_finger._pushCount = 0;
	_finger._angle = 0.0f;
	_changeFlag = false;
	_nextFlag = false;
	ClearAngle();

}

const int& CPU::GetNumber()
{
	return _finger._number;
}

const int& CPU::GetFingerNumber()
{
	return _finger._nowNumber;
}

const int& CPU::GetFingerValue()
{
	return _finger._setValue;
}

const bool& CPU::GetNextFlag()
{
	return _nextFlag;
}
