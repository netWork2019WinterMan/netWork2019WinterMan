#include "DxLib.h" 
#include "ControlGameResult.h"
#include "GameTask.h"
#include "ImageMng.h"

ControlGameResult::ControlGameResult()
{
	Init();
}

ControlGameResult::~ControlGameResult()
{
}

void ControlGameResult::Init()
{
	box1._UL.x = 150 - 127.5f;
	box1._UL.y = (SCREEN_SIZE_Y - 50) - 30;
	box1._DR.x = 150 + 127.5f;
	box1._DR.y = (SCREEN_SIZE_Y - 50) + 30;
	box1._scale = 1.0f;

	box2._UL.x = (SCREEN_SIZE_X - 150) - 205;
	box2._UL.y = (SCREEN_SIZE_Y - 50) - 35;
	box2._DR.x = (SCREEN_SIZE_X - 150) + 205;
	box2._DR.y = (SCREEN_SIZE_Y - 50) + 35;
	box2._scale = 1.0f;

	_modeFlag = NON_RE;
}

void ControlGameResult::Update()
{
	GetMousePoint(&mp._posX, &mp._posY);
}

void ControlGameResult::Draw()
{
	if (mp._posX > box1._UL.x && mp._posY > box1._UL.y && mp._posX < box1._DR.x && mp._posY < box1._DR.y)
	{
		box1._scale = 0.7f;
		if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0)
		{
			_modeFlag = MAIN;
		}
	}
	else
	{
		box1._scale = 0.6f;
	}

	if (mp._posX > box2._UL.x && mp._posY > box2._UL.y && mp._posX < box2._DR.x && mp._posY < box2._DR.y)
	{
		box2._scale = 0.6f;
		if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0)
		{
			_modeFlag = SM;
		}
	}
	else
	{
		box2._scale = 0.5f;
	}

	DrawRotaGraph(SCREEN_CENTER_X, 50, 0.8f, 0, IMAGE_ID("image/result.png"), true);
	DrawRotaGraph(150, SCREEN_SIZE_Y - 50, box1._scale, 0, IMAGE_ID("image/retry.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - 150, SCREEN_SIZE_Y - 50, box2._scale, 0, IMAGE_ID("image/modesentakuhe.png"), true);
}
