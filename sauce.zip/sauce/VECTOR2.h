#pragma once
class VECTOR2
{
public:
	float x, y;
private:

};

