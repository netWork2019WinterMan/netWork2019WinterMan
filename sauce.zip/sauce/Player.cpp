#include "Player.h"
#include "KeyMng.h"
#include "DxLib.h"

Player::Player(OYAKO oyako, int playerNumber)
{
	_finger._oyako = oyako;
	_finger._playerNumber = playerNumber;
}

Player::~Player()
{
}

void Player::Update()
{

	if (_changeFlag)
	{
		return;
	}

	_nextFlag = false;
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	if (GameMain::GetInstance().GetStopMotion())
	{
		return;
	}
	if (_finger._playerNumber == nextNumber && _finger._nowNumber <= 0)
	{
		TurnNext();
		return;
	}
	if (GameMain::GetInstance().GetNextNumber() == _finger._playerNumber)
	{
		if (_finger._pushCount >= MAX_TIME)
		{
			_nextFlag = true;

		}
		if (KeyMng::GetInstance().newKey[P1_ENTER])
		{
			(_finger._pushCount < MAX_TIME ? _finger._pushCount++ : 0);
		}
		else
		{
			(_finger._pushCount > 0 ? _finger._pushCount-- : 0);
		}
		if (KeyMng::GetInstance().trgKey[P1_RIGHT])
		{
			(_finger._setValue < GameMain::GetInstance().GetFingerValue() ? _finger._setValue++ : 0);
		}
		else if (KeyMng::GetInstance().trgKey[P1_LEFT])
		{
			(_finger._setValue > 0 ? _finger._setValue-- : 0);
		}
	}
	

	if (KeyMng::GetInstance().trgKey[P1_UP])
	{
		(_finger._number < 2 ? _finger._number++ : 0);
	}
	else if (KeyMng::GetInstance().trgKey[P1_DOWN])
	{
		(_finger._number > 0 ? _finger._number-- : 0);
	}

}

void Player::Draw()
{
	auto& nextNumber = GameMain::GetInstance().GetNextNumber();
	if (_finger._oyako == OYAKO::OYA)
	{
		DrawString(100, 100, "OYA_Player", 0xffffff);
	}
	else
	{
		DrawString(300, 100, "KO_Player", 0xffffff);
	}

	if (_finger._playerNumber == nextNumber)
	{
		DrawBox(95 + (50 * nextNumber), 245, 130 + (50 * nextNumber), 305, 0xff0000, true);
		DrawFormatString(100 + (50 * nextNumber), 200, 0xffffff, "%d", _finger._setValue);
		DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - _finger._pushCount, 0x00ffff, true);
		DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - MAX_TIME, 0xffffff, false);
	}
	DrawBox(100 + (50 * _finger._playerNumber), 250, 125 + (50 * _finger._playerNumber), 300, 0xffff00, true);

	DrawFormatString(100 + (50 * _finger._playerNumber), 230, 0xffffff, "�w:%d", _finger._number);
	DrawFormatString(100 + (50 * _finger._playerNumber), 310, 0xffffff, "��:%d", _finger._nowNumber);

	DrawFormatString(600, 400, 0xffffff, "%d", nextNumber);

}

void Player::ValueComparison()
{
	if (GetRand(2) == 0)
	{
		_waitTime++;
	}
	if ((KeyMng::GetInstance().trgKey[P1_ENTER] || _waitTime > 30) && _changeFlag)
	{
		KeyMng::GetInstance().trgKey[P1_ENTER] = false;
		TurnNext();
	}
	/* �w�肵���w�̑����ƍ��v�l�������Ȃ�� */
	else if (_finger._nowNumber > 0 && !_changeFlag)
	{
		auto fingerValue = GameMain::GetInstance().GetNumberValue();

		if (_finger._setValue == fingerValue)
		{
			--_finger._nowNumber;

			if (_finger._nowNumber <= 0)
			{
				GameMain::GetInstance().SubPlayerNumber(1);
			}
		}
		_changeFlag = true;

	}

}

void Player::TurnNext()
{
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	GameMain::GetInstance().SetStopMotion(false);
	GameMain::GetInstance().SetNextNumber((nextNumber >= MAX_PLAYER ? 1 :_finger._playerNumber + 1));
	_finger._setValue = 0;
	_finger._pushCount = 0;
	_changeFlag = false;
	//_number = 0;

}

const int& Player::GetNumber()
{
	return _finger._number;
}

const int& Player::GetFingerNumber()
{
	return _finger._nowNumber;
}

const int& Player::GetFingerValue()
{
	return _finger._setValue;
}

const bool& Player::GetNextFlag()
{
	return _nextFlag;
}
