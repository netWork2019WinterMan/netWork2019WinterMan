#include <iostream>
#include <vector>
#include "DxLib.h"
#include "GameTask.h"
#include "KeyMng.h"
#include "ImageMng.h"
#include "TitleControl.h"
#include "ControlSelectMode.h"
#include "ControlGameResult.h"
#include "GameMain.h"


using namespace std;

GameTask *GameTask::s_Instance = nullptr;

void GameTask::Create(void)
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("YubisumaFighters(��)");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);

	return 0;
}

void GameTask::GameUpdate()
{
	KeyMng::GetInstance().Update();
	// ���݂̃��[�h�ŉ�
	(this->*gMode[_currentMode])();
}

void GameTask::GameInit()
{
	DrawString(10, 10, "INIT", 0xffffff);

	//--------------------------------------------------
	// ������
	//--------------------------------------------------
	_currentMode = G_INIT;

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------

	// �^�C�g���ֈڍs
	if (_oldMode != G_RESULT)
	{
		_currentMode = G_TITLE;
	}
	// ���C���ֈڍs(���U���g����̃��g���C��)
	else
	{
		if (_futureMode == G_MAIN)
		{
			_currentMode = G_MAIN;
		}
		else if (_futureMode == G_SELECT_ROOM)
		{
			_currentMode = G_SELECT_ROOM;
		}
		else if (_futureMode == G_SELECT_MODE)
		{
			_currentMode = G_SELECT_MODE;
		}
	}
}

void GameTask::GameTitle()
{
	//--------------------------------------------------
	// ��ʕ`�揈��
	//--------------------------------------------------
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xf0f0f0, true);
	DrawString(10, 10, "TITLE", 0xffffff);
	DrawString(10, 30, "SPACE->MODESELECT", 0xffffff);

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------
	if (TitleControl::GetModeFlag())
	{
		_oldMode = _currentMode;
		_currentMode = G_SELECT_MODE;
		TitleControl::SetModeFlag(false);
	}

	//--------------------------------------------------
	// ����
	//--------------------------------------------------
	if (_createTimer % 50 == 0 || _createTimer == 0)
	{
		for (int i = 0; i < 20; i++)
		{
			tc.push_back(make_shared<TitleControl>());
		}
	}
	_createTimer++;

	//--------------------------------------------------
	// �X�V�A�`��
	//--------------------------------------------------
	auto itr = tc.begin();
	while (itr != tc.end())
	{
		(*itr)->Update();
		(*itr)->Draw();

		//--------------------------------------------------
		// ����
		//--------------------------------------------------
		if ((*itr)->GetHandRemove())
		{
			(*itr)->SetHandRemove(false);
			itr = tc.erase(itr,itr + 20);
		}
		else
		{
			itr++;
		}
	}
	DrawRotaGraph(SCREEN_CENTER_X, SCREEN_CENTER_Y, 1.0, 0, IMAGE_ID("image/yubisumafighters.png"), true);
}


void GameTask::GameSelectMode()
{
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xf0f0f0, true);
	DrawString(10, 10, "MODE SELECT", 0xffffff);
	DrawString(10, 30, "SPACE->MAIN", 0xffffff);
	DrawString(10, 50, "ENTER->ROOMSELECT", 0xffffff);

	if (csm.empty())
	{
		csm.push_back(make_shared<ControlSelectMode>());
	}

	for (auto itr : csm)
	{
		(*itr).Update();
		(*itr).Draw();

		//--------------------------------------------------
		// ��ʑJ�ڏ���
		//--------------------------------------------------

		if ((*itr).GetModeFlag() == PVE)
		{
			_oldMode = _currentMode;
			_currentMode = G_MAIN;
			(*itr).SetModeFlag(NON_SM);
		}
		if ((*itr).GetModeFlag() == TITLE_SM)
		{
			_oldMode = _currentMode;
			_currentMode = G_TITLE;
			(*itr).SetModeFlag(NON_SM);
		}

		//if ((*itr).GetModeFlag() == SR)
		//{
		//	_oldMode = _currentMode;
		//	_currentMode = G_SELECT_ROOM;
		//	(*itr).SetModeFlag(NON);
		//}
	}
}

// coming soon...
void GameTask::GameSelectRoom()
{
	DrawString(10, 10, "ROOM SELECT", 0xffffff);
	DrawString(10, 30, "SPACE->MAIN", 0xffffff);

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------

	// �Q�[�����C��(PvP)�ֈڍs
	if (KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		_oldMode = _currentMode;
		_currentMode = G_MAIN;
	}
}

void GameTask::GameMain()
{
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xf0f0f0, true);
	DrawString(10, 10, "MAIN", 0xffffff);
	DrawString(10, 30, "SPACE->RESULT", 0xffffff);

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------
	GameMain::GetInstance().Run();

	auto playerNumber = GameMain::GetInstance().GetNowPlayer();
	// ���U���g�ֈڍs
	if (KeyMng::GetInstance().trgKey[P1_SPACE] || playerNumber <= 1)
	{
		GameMain::GetInstance().Clear();
		GameMain::GetInstance().SetNowPlayer(MAX_PLAYER);
		_oldMode = _currentMode;
		_currentMode = G_RESULT;
	}
}

void GameTask::GameResult()
{
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xf0f0f0, true);
	DrawString(10, 10, "RESULT", 0xffffff);
	DrawString(10, 30, "SPACE->MAIN", 0xffffff);
	DrawString(10, 50, "ENTER->ROOMSELECT", 0xffffff);
	DrawString(10, 70, "LCtrl->MODESELECT", 0xffffff);

	if (cgr.empty())
	{
		cgr.push_back(make_shared<ControlGameResult>());
	}

	for (auto itr : cgr)
	{
		(*itr).Update();
		(*itr).Draw();

		//--------------------------------------------------
		// ��ʑJ�ڏ���
		//--------------------------------------------------

		if ((*itr).GetModeFlag() == MAIN)
		{
			_oldMode = _currentMode;
			_futureMode = G_MAIN;
			_currentMode = G_MAIN;
			(*itr).SetModeFlag(NON_RE);
		}
		if ((*itr).GetModeFlag() == SM)
		{
			_oldMode = _currentMode;
			_futureMode = G_SELECT_MODE;
			_currentMode = G_INIT;
			(*itr).SetModeFlag(NON_RE);
		}
	}

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------

	// ��������A�Q�[�����C���ֈڍs(���g���C)
	if (KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		_oldMode = _currentMode;
		_futureMode = G_MAIN;
		_currentMode = G_INIT;
	}
	// ���[�h�Z���N�g�ֈڍs
	if (KeyMng::GetInstance().trgKey[P1_LCtrl])
	{
		_oldMode = _currentMode;
		_futureMode = G_SELECT_MODE;
		_currentMode = G_INIT;
	}

	// coming soon...
	// ���[���Z���N�g�ֈڍs(PvP�̂�)
	if (KeyMng::GetInstance().trgKey[P1_ENTER])
	{
		_oldMode = _currentMode;
		_futureMode = G_SELECT_ROOM;
		_currentMode = G_INIT;
	}
}
