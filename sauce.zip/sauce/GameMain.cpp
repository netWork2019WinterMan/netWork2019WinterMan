#include "GameMain.h"
#include "Player.h"
#include "CPU.h"
#include "DxLib.h"

#include <algorithm>
GameMain::GameMain()
{
	_updater = &GameMain::Init;
}

GameMain::~GameMain()
{
}

void GameMain::Run()
{
	DrawString(10, 100, "Run", 0x000000);
	DrawFormatString(500, 100, 0x000000, "%d", _actor.size());
	DrawString(300, 400, "��������͂��Ă�������", 0x000000);
	DrawFormatString(500, 400, 0x000000, "%d", _numberValue);
	DrawFormatString(520, 400, 0x000000, "%d", _fingerValue);
	(this->*_updater)();

}

void GameMain::AddActor()
{
	for (int i = 0; i < MAX_PLAYER; ++i)
	{
		if (_actor.empty())
		{
			_actor.emplace_back(std::make_shared<Player>(VECTOR2(250,300),VECTOR2(250+256,300), OYAKO::OYA, ++_playerNumber));
		}
		else
		{
			_actor.emplace_back(std::make_shared<CPU>(OYAKO::KO, ++_playerNumber));
		}
	}
}

void GameMain::Clear()
{
	_updater = &GameMain::Init;
	_stopMotion = false;
	_nextNumber = 1;
	_playerNumber = 0;
	_actor.clear();
}

const int& GameMain::GetNextNumber()
{
	return _nextNumber;
}

const int& GameMain::GetNumberValue()
{
	return _numberValue;
}

const int& GameMain::GetFingerValue()
{
	return _fingerValue;
}

const int& GameMain::GetNowPlayer()
{
	return _nowPlayer;
}

const bool& GameMain::GetStopMotion()
{
	return _stopMotion;
}

void GameMain::SetNextNumber(int nextNumber)
{
	_nextNumber = nextNumber;
}

void GameMain::SetStopMotion(bool flag)
{
	_stopMotion = flag;
}

void GameMain::SetNowPlayer(int number)
{
	_nowPlayer = number;
}

void GameMain::SubPlayerNumber(int number)
{
	_nowPlayer -= number;
}

bool GameMain::Init()
{
	if (_actor.size() > MAX_PLAYER)
	{
		return false;
	}

	AddActor();

	_updater = &GameMain::Update;
	return true;
}

bool GameMain::Update()
{
	int numberValue = 0;
	int fingerValue = 0;
	for (auto& actor : _actor)
	{
		numberValue += actor->GetNumber();
		_numberValue = numberValue;

		fingerValue += actor->GetFingerNumber();
		_fingerValue = fingerValue;
	}
	for (auto& actor : _actor)
	{
		if (actor->GetNextFlag())
		{
			_stopMotion = true;
			actor->ValueComparison();
		}

		actor->Update();
		actor->Draw();
	}
	return true;
}
