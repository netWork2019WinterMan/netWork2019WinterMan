#include "AffineTransformation.h"

constexpr float PI = 3.141592653589793f;

namespace
{
	float Rad(float theta)
	{
		return 	float(theta / 180 * PI);
	}

	float Deg(float phi)
	{
		return float(phi / PI * 180);
	}

	Matrix Mat(VECTOR2 pos)
	{
		return Matrix(VECTOR2(1, 0, pos.x), VECTOR2(0, 1, pos.y), VECTOR2(0, 0, pos.z));
	}
}

AffineTransformation::AffineTransformation(): _mat(Matrix(VECTOR2(0,0,0), VECTOR2(0,0,0), VECTOR2(0,0,0)))
{
}

AffineTransformation::AffineTransformation(VECTOR2 p): _mat(Matrix(VECTOR2(0, 0, 0), VECTOR2(0, 0, 0), VECTOR2(0, 0, 0))), _pos(p)
{

}


AffineTransformation::~AffineTransformation()
{
}

void AffineTransformation::Init()
{
	_mat = Matrix(VECTOR2(1, 0, 0), VECTOR2(0, 1, 0), VECTOR2(0, 0, 1));
}

void AffineTransformation::Translation(float x, float y)
{
	_mat = Matrix(VECTOR2(1, 0, x), VECTOR2(0, 1, y), VECTOR2(0, 0, 1));
}

void AffineTransformation::TranslationAdd(float x, float y)
{
	Translation(_pos.x, _pos.y);
	_mat = Matrix(VECTOR2(1, 0, x), VECTOR2(0, 1, y), VECTOR2(0, 0, 1)) * _mat;

	_pos = _mat.GetTransAddVec(_mat);
}

void AffineTransformation::SetToRotation(float angle)
{
	auto theta = Rad(angle);
	_mat = Matrix(VECTOR2(cos(theta), -sin(theta), 0), VECTOR2(sin(theta), cos(theta), 0), VECTOR2(0, 0, 1));
}

void AffineTransformation::AddToRotation(float angle, float x, float y)
{
	auto theta = Rad(angle);
	Translation(_pos.x, _pos.y);
	_mat = Matrix(VECTOR2(cos(theta), -sin(theta), x), VECTOR2(sin(theta), cos(theta), y), VECTOR2(0, 0, 1)) * _mat;
	_pos = _mat.GetTransAddVec(_mat);

}

void AffineTransformation::Rotation(float angle)
{
	auto theta = Rad(angle);
	Translation(_pos.x, _pos.y);
	_mat = Matrix(VECTOR2(cos(theta), -sin(theta), 0), VECTOR2(sin(theta), cos(theta), 0), VECTOR2(0, 0, 1)) * _mat;
	_pos = _mat.GetTransAddVec(_mat);
}

const VECTOR2& AffineTransformation::Rotation(VECTOR2 pos , float angle)
{
	auto theta = Rad(angle);
	auto value = Matrix(VECTOR2(cos(theta), -sin(theta), 0), VECTOR2(sin(theta), cos(theta), 0), VECTOR2(0, 0, 1)) * Mat(pos);
	return _mat.GetTransAddVec(value);
}

void AffineTransformation::Skew(float x, float y)
{
	Translation(_pos.x, _pos.y);
	_mat = Matrix(VECTOR2(1, x, 0), VECTOR2(y, 1, 0), VECTOR2(0, 0, 1)) * _mat;
	_pos = _mat.GetTransAddVec(_mat);
}


const VECTOR2& AffineTransformation::Skew(VECTOR2 pos, float x, float y)
{
	auto value = Matrix(VECTOR2(1, x, 0), VECTOR2(y, 1, 0), VECTOR2(0, 0, 1)) * Mat(pos);
	return _mat.GetTransAddVec(value);
}

const VECTOR2& AffineTransformation::GetVector()
{
	return _pos;
}
