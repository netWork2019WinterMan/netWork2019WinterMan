#pragma once
#include "Actor.h"
#include "AffineTransformation.h"
#include < memory>
class CPU :
	public Actor
{
public:
	CPU(OYAKO oyako, int playerNumber);
	CPU();
	~CPU();

	void Update();
	void Draw();

	void ClearAngle();


	void ValueComparison();
	void TurnNext();
	const int& GetNumber();
	const int& GetFingerNumber();
	const int& GetFingerValue();
	const bool& GetNextFlag();

private:
	struct Finger
	{
		OYAKO _oyako;
		VECTOR2 _pos;
		int _playerNumber = 0;//��ڲ԰�̎��ʔԍ�
		int _number = 0;//������w�̐�

		int _setValue = 0;//�w�̑����̗\�z
		int _nowNumber = 2;//���݂̎w�̐�
		int _pushCount = 0;
		float _angle = 0.0f;
	};

	struct sinCurve
	{
		int _count1 = 0;
		int _count2 = 0;
		int _count3 = 0;
	};

	Finger _finger;
	Finger _thumbL;
	Finger _thumbR;
	sinCurve _sinC;
	bool _nextFlag = false;
	bool _changeFlag = false;
	int _waitTime = 0;

	std::shared_ptr<AffineTransformation> _mat;
};

