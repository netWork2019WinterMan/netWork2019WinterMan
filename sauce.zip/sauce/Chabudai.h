#pragma once
#include "VECTOR2.h"

constexpr int SEP_NUM_X = 1;
constexpr int SEP_NUM_Y = 1024;
constexpr int SEP_NUM_ALL = SEP_NUM_X * SEP_NUM_Y;

class Chabudai
{
public :
	Chabudai();
	~Chabudai();
	// �ݸ����
	static Chabudai& GetInstance(void)
	{
		static Chabudai instance;
		return instance;
	}

	void Init();
	void Calc();
	void DrawAshi();
	void DrawDai(int);
	void DrawTatami(int);
public:
	struct chabudai 
	{
		VECTOR2 _pos;
		VECTOR2 _screenPos;
		float _size;
		float _screenDist;
	};
	struct tatami
	{
		VECTOR2 _pos;
		VECTOR2 _screenPos;
		float _size;
		float _screenDist;
	};
	struct cam 
	{
		VECTOR2 _pos;
	};
	chabudai cha;
	tatami ta;
	cam cm;
	int _mapSepDai[SEP_NUM_ALL+1];
	int _mapSepTatami[SEP_NUM_ALL+1];
};

