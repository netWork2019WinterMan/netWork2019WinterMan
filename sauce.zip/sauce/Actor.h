#pragma once
#include "GameMain.h"

constexpr unsigned int MAX_TIME = 50;
class Actor
{
public:
	Actor(OYAKO oyako);
	Actor();
	~Actor();

	virtual void Update() = 0;
	virtual void Draw() = 0;

	virtual void ValueComparison() = 0;
	virtual void TurnNext() = 0;
	virtual const int& GetNumber() = 0;
	virtual const int& GetFingerNumber() = 0;
	virtual const int& GetFingerValue() = 0;
	virtual const bool& GetNextFlag() = 0;

};

