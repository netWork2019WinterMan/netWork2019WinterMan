#pragma once
#include "NetWorkState.h"

struct ClientState :NetWorkState
{
	ClientState();
	NetWorkMode GetMode(void) { return NetWorkMode::GUEST; };
private:
	bool CheckNetWork(void);
	bool CloseNetWork(void);
};

// EOF