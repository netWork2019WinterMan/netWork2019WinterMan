#pragma once
#include "VECTOR2.h"

constexpr int CIRCLE = 360;
constexpr int HAND_INTERVAL_X = SCREEN_SIZE_X / 10;
constexpr int HAND_INTERVAL_Y = SCREEN_SIZE_Y / 5;
constexpr int HAND_VALUE_X = 20;
constexpr int HAND_VALUE_Y = 5;
constexpr int HAND_VALUE_ALL = HAND_VALUE_X * HAND_VALUE_Y;

class TitleControl
{
public:
	TitleControl();
	~TitleControl();
	bool GetHandRemove() { return _removeFlag; };
	void SetHandRemove(bool _removeFlag) { this->_removeFlag = _removeFlag; }
	static void SetModeFlag(bool _Flag) { _modeFlag = _Flag; }
	static bool GetModeFlag() { return _modeFlag; }
	void Update();
	void Draw();

private:
	struct character {
		VECTOR2 _pos;
		float _size;
		float _angle;
		bool _remove;
		float _theta;
		float _speed;
	};

	struct box {
		VECTOR2 _UL, _DR;
		float _scale;
	};

	struct Mouse {
		int _posX, _posY;
	};

	character ch = { VECTOR2(0.0f,0.0f,0.0f),0.0f,0.0f,false,0.0f,0.0f };
	box b = { VECTOR2(0.0f,0.0f,0.0f),VECTOR2(0.0f,0.0f,0.0f),0.0f};
	Mouse m;


	//--------------------------------------------------
	// �ϐ��Q
	//--------------------------------------------------

	static int _instanceCnt;		// �������J�E���g
	static int _handPosCntX;			// �^�C�g���̎�̍��W�p
	static int _handPosCntY;			// �^�C�g���̎�̍��W�p
	static bool _removeFlag;
	static bool _modeFlag;				//true�Ń��[�h�Z���N�g��

};

