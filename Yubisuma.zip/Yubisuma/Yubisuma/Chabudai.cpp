#include "Chabudai.h"
#include "Dxlib.h"
#include "GameTask.h"
#include "ImageMng.h"

Chabudai::Chabudai()
{
	Init();
}

Chabudai::~Chabudai()
{
}


void Chabudai::Init()
{
	cm._pos.x = 0.0f;
	cm._pos.y = 0.0f;
	cm._pos.z = 0.0f;

	cha._screenDist = 300;

	cha._pos.x = SCREEN_CENTER_X;
	cha._pos.y = 100.0f;
	cha._pos.z = 0.0f;
	cha._screenPos.x = SCREEN_CENTER_X;
	cha._screenPos.y = 0.0f;
	cha._screenPos.z = cha._screenDist;
	cha._size = 0.0f;

	ta._screenDist = 200;

	ta._pos.x = SCREEN_CENTER_X;
	ta._pos.y = 200.0f;
	ta._pos.z = 0.0f;
	ta._screenPos.x = SCREEN_CENTER_X;
	ta._screenPos.y = 0.0f;
	ta._screenPos.z = ta._screenDist;
	ta._size = 0.0f;
	
	LoadDivGraph("image/chabudai.png", SEP_NUM_ALL, SEP_NUM_X, SEP_NUM_Y, SEP_NUM_Y, SEP_NUM_X, _mapSepDai);
	LoadDivGraph("image/tatami5bai.png", SEP_NUM_ALL, SEP_NUM_X,SEP_NUM_Y , (SEP_NUM_Y * 5) , SEP_NUM_X, _mapSepTatami);
}

void Chabudai::Calc()
{
	for (int i = 0; i < SEP_NUM_ALL; i++)
	{
		ta._pos.z = ta._screenDist + i * 2.0f;

		ta._screenPos.z = ta._screenDist / ta._pos.z;
		ta._screenPos.y = ((ta._screenPos.z * ta._pos.y) + SCREEN_CENTER_Y) + 130;
		ta._size = 2 * ta._screenPos.z; 
		DrawTatami(SEP_NUM_ALL - i);
	}

	DrawAshi();

	for (int i = 0; i < SEP_NUM_ALL; i++)
	{
		cha._pos.z = cha._screenDist + i * 5.0f;

		cha._screenPos.z = cha._screenDist / cha._pos.z;
		cha._screenPos.y = (cha._screenPos.z * cha._pos.y) + SCREEN_CENTER_Y + 75;
		cha._size = 3 * cha._screenPos.z;
		DrawDai(SEP_NUM_ALL - i);
	}
}

void Chabudai::DrawAshi()
{
	DrawRotaGraph(cha._pos.x - 250, cha._pos.y + 360, 0.4f, 0, IMAGE_ID("image/chabudai_ashi.png"), true);
	DrawRotaGraph(cha._pos.x + 250, cha._pos.y + 360, 0.4f, 0, IMAGE_ID("image/chabudai_ashi.png"), true);
}

void Chabudai::DrawDai(int i)
{
	DrawRotaGraphF(cha._screenPos.x, cha._screenPos.y, cha._size, 0, _mapSepDai[i], true);
}

void Chabudai::DrawTatami(int i)
{
	if (cm._pos.z < ta._screenPos.z)
	{
		DrawRotaGraphF(ta._screenPos.x, ta._screenPos.y, ta._size, 0, _mapSepTatami[i], true);
	}
}
