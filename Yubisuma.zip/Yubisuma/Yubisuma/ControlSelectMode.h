#pragma once
#include "VECTOR2.h"

// ���̃N���X�͌p�������邱�ƁI

enum PVE_PVE {
	NON_SM,
	PVE,
	SR,		// ���[���Z���N�g
	TITLE_SM
};

class ControlSelectMode
{
public:
	ControlSelectMode();
	~ControlSelectMode();
	void SetModeFlag(int _modeFlag) { this->_modeFlag = _modeFlag; }
	int GetModeFlag() { return _modeFlag; }
	const bool& GetPvPFlag() { return _PvPFlag; }
	void Init();
	void Update();
	void Draw();
private:
	struct MousePoint
	{
		int _posX, _posY;
	};

	struct BoxPvE
	{
		VECTOR2 _UL,_DR;
		float _scale;
	};

	struct BoxPvP
	{
		VECTOR2 _UL, _DR;
		float _scale;
	};

	struct BoxBack
	{
		VECTOR2 _UL, _DR;
		float _scale;
	};

	MousePoint mp;
	BoxPvE box1;
	BoxPvP box2;
	BoxBack box3;

	int _modeFlag;		// 0:�����l,1:PvE,2:RoomSelect
	bool _PvPFlag = false;
};

