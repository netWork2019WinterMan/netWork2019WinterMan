#pragma once
#include "GameMain.h"
#include "VECTOR2.h"

constexpr unsigned int MAX_TIME = 50;


struct Kakegoe {
	int _yu, _bi, _su, _ma;
	bool _yuF, _biF, _suF, _maF;
	bool _numFalg;
	int _countYu, _countBi, _countSu, _countMa, _countNum;
	int _numVoice[9];
};
class Actor
{
public:
	Actor(OYAKO oyako);
	Actor();
	~Actor();

	virtual void Update() = 0;
	virtual void Draw() = 0;

	virtual void ClearAngle() = 0;

	virtual void ValueComparison() = 0;
	virtual void TurnNext() = 0;
	virtual const int& GetNumber() = 0;
	virtual const int& GetFingerNumber() = 0;
	virtual const int& GetFingerValue() = 0;
	virtual const bool& GetNextFlag() = 0;

};

