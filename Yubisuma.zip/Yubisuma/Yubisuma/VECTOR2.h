#pragma once
#include<vector>
class VECTOR2
{
public:
	float x, y, z;

	std::vector<float>vec;
	VECTOR2() {};
	VECTOR2(float x, float y) :x(x), y(y) {}
	VECTOR2(float x, float y, float z) :x(x), y(y), z(z)
	{
		vec.emplace_back(x);
		vec.emplace_back(y);
		vec.emplace_back(z);
	}
private:

};

