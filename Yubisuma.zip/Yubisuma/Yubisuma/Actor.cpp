#include "Actor.h"

Actor::Actor(OYAKO oyako)
{
}

Actor::Actor()
{
}

Actor::~Actor()
{
}
