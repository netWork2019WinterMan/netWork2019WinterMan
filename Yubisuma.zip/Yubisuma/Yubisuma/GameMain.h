#pragma once
#include "GameTask.h"
#include <string>
#include <vector>
#include <memory>


enum class OYAKO
{
	OYA,
	KO
};

class Actor;

constexpr unsigned int MAX_PLAYER = 4;
constexpr unsigned int MIN_PLAYER = 2;

class GameMain
{
public:
	GameMain();
	~GameMain();

	// �ݸ����
	static GameMain& GetInstance(void)
	{
		static GameMain instance;
		return instance;
	}
	void Run();

	void AddActor();
	void Clear();

	const int& GetNextNumber();
	const int& GetNumberValue();
	const int& GetFingerValue();
	const int& GetNowPlayer();
	const bool& GetStopMotion();
	const Rule& GetGameRule();
	void SetNextNumber(int nextNumber);
	void SetStopMotion(bool flag);
	void SetNowPlayer(int number);
	void SubPlayerNumber(int number);
	void SetGameRule(const Rule& rule);
	void SetAngleReset(bool flag);


private:
	bool (GameMain::* _updater)();

	bool Init();
	bool Update();
	void Draw();
	std::vector<std::shared_ptr<Actor>> _actor;

	int _playerNumber = 0; //��ڲ԰�̎��ʔԍ�
	int _nowPlayer = MAX_PLAYER;//���ݎQ�����Ă�����ڲ԰�̐�
	int _nextNumber = 1; //������ڲ԰�̎��ʔԍ�
	
	int _numberValue = 0; //���v�̐��l

	int _fingerValue = 0;//���݂̎w�̑���


	bool _stopMotion = false;

	bool _angleReset = false;

	int yoso;
	int _gokeiNum[11];

	Rule _rule;

};
