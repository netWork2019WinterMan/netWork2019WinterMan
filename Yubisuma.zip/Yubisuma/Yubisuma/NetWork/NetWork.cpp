#include <algorithm>
#include "NetWork.h"
#include "HostState.h"
#include "ClientState.h"
#include "../GameTask.h"

std::unique_ptr<NetWork, NetWork::NetWorkDeleter> NetWork::s_Instance(new NetWork());

NetWork::NetWork()
{
}

NetWork::~NetWork()
{
}

void NetWork::GetIpAddress(void)
{

}

bool NetWork::SetNetWorkMode(NetWorkMode mode)
{
	if (state_s)
	{
		// νĂ��ײ��ĂƂ��ē��삵�Ă���Ή������Ȃ�
		return false;
	}

	if (mode == NetWorkMode::HOST)
	{
		state_s = std::make_shared<HostState>();
		if (state_s->GetActive())
		{
			PreparationListenNetWork();
			return true;
		}
	}
	else
	{
		state_s = std::make_shared<ClientState>();
		if (state_s->GetActive())
		{
			return true;
		}
	}
	state_s.reset();
	
	return false;
}

bool NetWork::Update(void)
{
	if (!state_s)
	{
		return false;
	}
	return (*state_s)();
}

NetWorkMode NetWork::GetMode(void)
{
	if (state_s)
	{
		return state_s->GetMode();
	}
	return NetWorkMode::OFFLINE;
}

NetState NetWork::GetState(void)
{
	if (state_s)
	{
		return state_s->GetState();
	}
	return NetState::NON;
}

bool NetWork::CloseNetWork(void)
{
	if (state_s)
	{
		state_s->CloseNetWork();
		state_s.reset();
	}
	return true;
}

bool NetWork::SetSendMes(strSendMes mes)
{
	if (state_s)
	{
		return state_s->SetSendMes(mes);
	}
	return false;
}

strSendMes NetWork::GetData(void)
{
	if (state_s)
	{
		return state_s->GetData();
	}
	return { mesType::NON,0,0,0 };
}

void NetWork::Draw(void)
{
	if (state_s)
	{
		state_s->Draw();
	}
}

// EOF