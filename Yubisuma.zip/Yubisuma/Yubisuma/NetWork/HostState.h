#pragma once
#include "NetWorkState.h"

struct HostState :NetWorkState
{
	HostState();
	NetWorkMode GetMode(void) { return NetWorkMode::HOST; };
private:
	bool CheckNetWork(void);
	bool CloseNetWork(void);
};

// EOF