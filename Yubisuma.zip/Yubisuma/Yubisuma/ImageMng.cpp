#include "DxLib.h"
#include "ImageMng.h"
#include <assert.h>

const int& ImageMng::SetImage(string imagePath)
{
	// �摜������
	if (mp.find(imagePath) == mp.end())
	{
		mp[imagePath] = LoadGraph(imagePath.c_str());
	}
	return mp[imagePath];
}

const int& ImageMng::SetSound(string soundPath)
{
	// �摜������
	if (mp.find(soundPath) == mp.end())
	{
		mp[soundPath] = LoadBGM(soundPath.c_str());
	}
	return mp[soundPath];
}
