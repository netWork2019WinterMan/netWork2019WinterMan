#include "GameTask.h"
#include "GameMain.h"
#include "Player.h"
#include "EnemyPlayer.h"
#include "CPU.h"
#include "ImageMng.h"
#include "DxLib.h"

#include <algorithm>
GameMain::GameMain()
{
	_updater = &GameMain::Init;
	LoadDivGraph("image/num.png", 11, 11, 1, 100, 100, _gokeiNum);
}

GameMain::~GameMain()
{
}

void GameMain::Run()
{
	(this->*_updater)();
	//DrawLine(SCREEN_CENTER_X, 0, SCREEN_CENTER_X, SCREEN_SIZE_Y, 0x000000, 1);
}

void GameMain::AddActor()
{
	for (int i = 0; i < _rule._playerMax; ++i)
	{
		if (_actor.empty())
		{
			//_actor.emplace_back(std::make_shared<CPU>(OYAKO::OYA, ++_playerNumber));
			_actor.emplace_back(std::make_shared<Player>(VECTOR2(250,SCREEN_SIZE_Y - 170),VECTOR2(250 + 203, SCREEN_SIZE_Y - 170), OYAKO::OYA, ++_playerNumber));
		}
		else
		{
			if (_rule._nowPlayerNum > 0)
			{
				_actor.emplace_back(std::make_shared<EnemyPlayer>(VECTOR2(250, SCREEN_SIZE_Y - 170), VECTOR2(250 + 203, SCREEN_SIZE_Y - 170), OYAKO::OYA, ++_playerNumber));
				--_rule._nowPlayerNum;
			}
			else
			{
				_actor.emplace_back(std::make_shared<CPU>(OYAKO::KO, ++_playerNumber));
			}
		}
	}
}

void GameMain::Clear()
{
	_updater = &GameMain::Init;
	_stopMotion = false;
	_nextNumber = 1;
	_playerNumber = 0;
	_actor.clear();
}

const int& GameMain::GetNextNumber()
{
	return _nextNumber;
}

const int& GameMain::GetNumberValue()
{
	return _numberValue;
}

const int& GameMain::GetFingerValue()
{
	return _fingerValue;
}

const int& GameMain::GetNowPlayer()
{
	return _nowPlayer;
}

const bool& GameMain::GetStopMotion()
{
	return _stopMotion;
}

const Rule& GameMain::GetGameRule()
{
	return _rule;
}

void GameMain::SetNextNumber(int nextNumber)
{
	_nextNumber = nextNumber;
}

void GameMain::SetStopMotion(bool flag)
{
	_stopMotion = flag;
}

void GameMain::SetNowPlayer(int number)
{
	_nowPlayer = number;
}

void GameMain::SubPlayerNumber(int number)
{
	_nowPlayer -= number;
}

void GameMain::SetGameRule(const Rule& rule)
{
	_rule = rule;
}

void GameMain::SetAngleReset(bool flag)
{
	_angleReset = flag;
}

bool GameMain::Init()
{
	if (_actor.size() > _rule._playerMax)
	{
		return false;
	}

	SetNowPlayer(_rule._playerMax);
	AddActor();

	_updater = &GameMain::Update;
	return true;
}

bool GameMain::Update()
{
	int numberValue = 0;
	int fingerValue = 0;
	for (auto& actor : _actor)
	{
		numberValue += actor->GetNumber();
		_numberValue = numberValue;

		fingerValue += actor->GetFingerNumber();
		_fingerValue = fingerValue;
	}
	for (auto& actor : _actor)
	{
		if (actor->GetNextFlag())
		{
			_stopMotion = true;
			actor->ValueComparison();
		}

		actor->Update();
		actor->Draw();
	}

	if (_angleReset)
	{
		for (auto& actor : _actor)
		{
			actor->ClearAngle();
		}
		_angleReset = false;
	}
	Draw();
	return true;
}

void GameMain::Draw()
{
	DrawRotaGraph(80, 50, 0.7f, 0, IMAGE_ID("image/yoso.png"), true);
	DrawRotaGraph(80, 100, 0.73f, 0, IMAGE_ID("image/gokei.png"), true);
	DrawRotaGraph(80 + 70, 100, 0.73f, 0, _gokeiNum[_numberValue], true);
}
