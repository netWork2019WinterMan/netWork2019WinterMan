#include "Player.h"
#include "KeyMng.h"
#include "DxLib.h"
#include "ImageMng.h"
#include "AffineTransformation.h"
#include "GameTask.h"
#include "MouseMng.h"
#include <cmath>

Player::Player(VECTOR2 posLeft, VECTOR2 posRight, OYAKO oyako, int playerNumber)
{
	_finger._pushCount = 0;
	_finger._oyako = oyako;
	_finger._playerNumber = playerNumber;
	_finger.posLeft = posLeft;
	_finger.posRight = posRight;
	_handle = IMAGE_ID("image/leftHand.png");
	_finger.w = 256, _finger.h = 256;

	_thumbL.posLeft = VECTOR2(_finger.posLeft.x + 110, _finger.posLeft.y + 20, 1);
	_thumbR.posRight = VECTOR2(_finger.posRight.x + 80, _finger.posRight.y + 20, 1);

	_thumbL.w = 65, _thumbL.h = 140;
	_thumbR.w = 65, _thumbR.h = 140;

	_thumbR._fadeout = 0.0f;
	_thumbL._fadeout = 0.0f;

	_mat = std::make_shared<AffineTransformation>(_thumbL.posLeft);

	_count = 0;

	_finger._wheelL = 0;
	_finger._wheelR = 0;

	k._yu = SOUND_ID("sound/yu.wav");
	k._bi = SOUND_ID("sound/bi.wav");
	k._su = SOUND_ID("sound/su.wav");
	k._ma = SOUND_ID("sound/ma.wav");
	k._yuF = false;
	k._biF = false;
	k._suF = false;
	k._maF = false;
	k._countYu = 0;
	k._countYu = 0;
	k._countYu = 0;
	k._countYu = 0;

	k._numVoice[0] = SOUND_ID("sound/0.wav");
	k._numVoice[1] = SOUND_ID("sound/1.wav");
	k._numVoice[2] = SOUND_ID("sound/2.wav");
	k._numVoice[3] = SOUND_ID("sound/3.wav");
	k._numVoice[4] = SOUND_ID("sound/4.wav");
	k._numVoice[5] = SOUND_ID("sound/5.wav");
	k._numVoice[6] = SOUND_ID("sound/6.wav");
	k._numVoice[7] = SOUND_ID("sound/7.wav");
	k._numVoice[8] = SOUND_ID("sound/8.wav");

	k._numFalg = false;

	LoadDivGraph("image/numW.png", 11, 11, 1, 100, 100, _numW);
	LoadDivGraph("image/num.png", 11, 11, 1, 100, 100, _num);
}

Player::~Player()
{
}

void Player::Update()
{

	if (_changeFlag)
	{
		return;
	}

	_nextFlag = false;
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	if (GameMain::GetInstance().GetStopMotion())
	{
		return;
	}
	if (_finger._playerNumber == nextNumber && _finger._nowNumber <= 0)
	{
		TurnNext();
		return;
	}

	// Xbox�R���p
	if (GetJoypadNum() > 0)
	{
		//��
		stickL = KeyMng::GetInstance().input.ThumbLY;
		stickLMax = static_cast<float>(50.0f / 32767);
		stickL *= stickLMax;

		angleL = KeyMng::GetInstance().input.ThumbLY;
		angleLMax = static_cast<float>(-10.0f / 32767);
		angleL *= angleLMax;
		angle = angleL;

		sizeL = KeyMng::GetInstance().input.ThumbLY;
		sizeLMax = static_cast<float>(6.0f / 32767);
		sizeL *= sizeLMax;
		size = sizeL + 1.0f;
	}
	else
	{
		// �}�E�X�p
		if (MouseMng::GetInstance().newKey[P1_PUSH])
		{
			if (_finger._wheelL < 50)
			{
				_finger._wheelL += GetMouseWheelRotVol() * 2;
			}
			else
			{
				_finger._wheelL = 50;
			}
		}
		else
		{
			_finger._wheelL = 0;
		}

		stickL = _finger._wheelL;
		angleL =  _finger._wheelL;
		sizeL = _finger._wheelL;

		angleLMax = static_cast<float>(-10.0f / 50);
		sizeLMax = static_cast<float>(6.0f / 50.0f);

		angleL *= angleLMax;
		sizeL *= sizeLMax;

		angle = angleL;
		size = sizeL + 1.0f;

	}

	DrawFormatString(100, 100, 0x000000, "_wheelL:%d", _finger._wheelL);
	DrawFormatString(100, 115, 0x000000, "_wheelR:%d", _finger._wheelR);

	if (stickL > 20 || _finger._wheelL > 20)
	{
		_thumbL._number = 1;
		if (_thumbL._number > 0)
		{
			(_thumbL._angle > -10.0f ? _thumbL._angle = angle : 0);
			(_thumbL._size < 6.0f ? _thumbL._size = size : 0);
		}
	}
	else
	{
		_thumbL._number = 0;
		(_thumbL._angle < 0 ? _thumbL._angle = angle : 0);
		(_thumbL._size > 1.0f ? _thumbL._size = size : 0);
	}

	// Xbox�R���p
	if (GetJoypadNum() > 0)
	{
		//�E
		stickR = KeyMng::GetInstance().input.ThumbRY;
		stickRMax = static_cast<float>(50.0f / 32767);
		stickR *= stickRMax;

		angleR = KeyMng::GetInstance().input.ThumbRY;
		angleRMax = static_cast<float>(-10.0f / 32767);
		angleR *= angleRMax;
		angleRValue = angleR;

		sizeR = KeyMng::GetInstance().input.ThumbRY;
		sizeRMax = static_cast<float>(6.0f / 32767);
		sizeR *= sizeRMax;
		sizeRValue = sizeR + 1.0f;
	}
	else
	{
		// �}�E�X�p
		if (MouseMng::GetInstance().newKey[P1_POP])
		{
			if (_finger._wheelR < 50)
			{
				_finger._wheelR += GetMouseWheelRotVol() * 2;
				if (MouseMng::GetInstance().newKey[P1_PUSH])
				{
					_finger._wheelR = _finger._wheelL;
				}
			}
			else
			{
				_finger._wheelR = 50;
			}
		}
		else
		{
			_finger._wheelR = 0;
		}

		stickR = _finger._wheelR;
		angleR = _finger._wheelR;
		sizeR = _finger._wheelR;

		angleRMax = static_cast<float>(-10.0f / 50);
		sizeRMax = static_cast<float>(6.0f / 50.0f);

		angleR *= angleRMax;
		sizeR *= sizeRMax;

		angleRValue = angleR;
		sizeRValue = sizeR + 1.0f;
	}

	if (stickR > 20 || _finger._wheelR > 20)
	{
		_thumbR._number = 1;
		if (_thumbR._number > 0)
		{
			(_thumbR._angle > -10.0f ? _thumbR._angle = angleRValue : 0);
			(_thumbR._size < 6.0f ? _thumbR._size = sizeRValue : 0);
		}
	}
	else
	{
		_thumbR._number = 0;
		(_thumbR._angle < 0 ? _thumbR._angle = angleRValue : 0);
		(_thumbR._size > 1.0f ? _thumbR._size = sizeRValue : 0);
	}

	if (GameMain::GetInstance().GetNextNumber() == _finger._playerNumber)
	{
		if (_finger._pushCount >= MAX_TIME - 10)
		{
			_nextFlag = true;
		}

		if (stickL > 1 || _finger._wheelL > 1)
		{
			(_finger._pushCount < MAX_TIME ? _finger._pushCount = stickL : 0);
		}

		if (stickR > 1 || _finger._wheelR > 1)
		{
			(_finger._pushCount < MAX_TIME ? _finger._pushCount = stickR : 0);
		}

		if (stickL > 1 || _finger._wheelL > 1)
		{
			_thumbL._number = 1;
			(_finger._pushCount < MAX_TIME ? _finger._pushCount = stickL : 0);
			if (_thumbL._number > 0)
			{
				(_thumbL._angle > -10.0f ? _thumbL._angle = angle : 0);
				(_thumbL._size < 6.0f ? _thumbL._size = size : 0);
			}
		}
		else
		{
			_thumbL._number = 0;
			(_thumbL._angle < 0 ? _thumbL._angle = angle : 0);
			(_thumbL._size > 1.0f ? _thumbL._size = size : 0);
		}

		if (stickL < -1 && stickR < -1 || _finger._wheelL < -1 && _finger._wheelR < -1)
		{
			if (GetJoypadNum() > 0)
			{
				(_finger._pushCount < MAX_TIME ? _finger._pushCount = -(stickL + stickR) : 0);
			}
			else
			{
				(_finger._pushCount < MAX_TIME ? _finger._pushCount = -(_finger._wheelL + _finger._wheelR) : 0);
			}
		}
		
		if (_finger._pushCount < 5)
		{
			_finger._pushCount = 0;
		}

		if (KeyMng::GetInstance().trgKey[P1_Y])
		{
			(_finger._setValue < GameMain::GetInstance().GetFingerValue() ? _finger._setValue++ : 0);
		}
		else if (KeyMng::GetInstance().trgKey[P1_X])
		{
			(_finger._setValue > 0 ? _finger._setValue-- : 0);
		}
	}

	_finger._number = _thumbL._number + _thumbR._number;

	if (_finger._pushCount >= 40 / 4 && _finger._pushCount < (40 / 4) * 2)
	{
		k._yuF = true;
	}
	else if (_finger._pushCount >= (40 / 4) * 2 && _finger._pushCount < (40 / 4) * 3)
	{
		k._biF = true;
	}
	else if (_finger._pushCount >= (40 / 4) * 3 && _finger._pushCount < (40 / 4) * 4)
	{
		k._suF = true;
	}
	else if (_finger._pushCount >= (40 / 4) * 4)
	{
		k._maF = true;
	}
	//DrawFormatString(100, 100, 0xffffff, "%f", _finger._pushCount);
	PlaySounds();
}

void Player::Draw()
{
	auto posValue = [&](const VECTOR2& pos, const float& angle) {
		VECTOR2 p;
		p = _mat->Rotation(VECTOR2(1.0f, pos.y, pos.z), angle);
		p.x = pos.x;
		return p;
	};
	auto& nextNumber = GameMain::GetInstance().GetNextNumber();

	_mat->SetPos(_thumbL.posLeft);
	//���e�w����
	auto leftUp = VECTOR2(_thumbL.posLeft.x, _thumbL.posLeft.y, _thumbL.posLeft.z);
	auto rightUp = VECTOR2(_thumbL.posLeft.x + _thumbL.w, _thumbL.posLeft.y, _thumbL.posLeft.z);
	auto rightDown = VECTOR2(_thumbL.posLeft.x + _thumbL.w, _thumbL.posLeft.y + _thumbL.h, _thumbL.posLeft.z);
	auto leftDown = VECTOR2(_thumbL.posLeft.x, _thumbL.posLeft.y + _thumbL.h, _thumbL.posLeft.z);

	leftUp = posValue(leftUp, _thumbL._angle);
	rightUp = posValue(rightUp, _thumbL._angle);
	rightDown = posValue(rightDown, _thumbL._angle);
	leftDown = posValue(leftDown, _thumbL._angle);
	
	_count++;
	//����sa
	DrawRotaGraph((_finger.posLeft.x + _finger.w / 2) - sin(PI * 2 / 300 * _count) * 5.0f,
		(_finger.posLeft.y + _finger.h / 2) - sin(PI * 2 / 300 * _count) * 5.0f + _thumbL._fadeout,
		1, 0, IMAGE_ID("image/leftHand.png"), true);

	DrawModiGraph(leftUp.x - (2 * _thumbL._size) + (_thumbL._angle * 2) - sin(PI * 2 / 300 * _count) * 5.0f, leftUp.y - (2 * _thumbL._size) - sin(PI * 2 / 300 * _count) * 5.0f + _thumbL._fadeout,
		rightUp.x + (2 * _thumbL._size) + (_thumbL._angle * 2) - sin(PI * 2 / 300 * _count) * 5.0f, rightUp.y - (2 * _thumbL._size) - sin(PI * 2 / 300 * _count) * 5.0f + _thumbL._fadeout,
		rightDown.x - sin(PI * 2 / 300 * _count) * 5.0f, rightDown.y - sin(PI * 2 / 300 * _count) * 5.0f + _thumbL._fadeout,
		leftDown.x - sin(PI * 2 / 300 * _count) * 5.0f, leftDown.y - sin(PI * 2 / 300 * _count) * 5.0f + _thumbL._fadeout, IMAGE_ID("image/leftFinger.png"), true);

	_mat->SetPos(_thumbR.posRight);

	//�E��
	leftUp = VECTOR2(_thumbR.posRight.x, _thumbR.posRight.y, _thumbR.posRight.z);
	rightUp = VECTOR2(_thumbR.posRight.x + _thumbR.w, _thumbR.posRight.y, _thumbR.posRight.z);
	rightDown = VECTOR2(_thumbR.posRight.x + _thumbR.w, _thumbR.posRight.y + _thumbR.h, _thumbR.posRight.z);
	leftDown = VECTOR2(_thumbR.posRight.x, _thumbR.posRight.y + _thumbR.h, _thumbR.posRight.z);

	if (_thumbR._number > 0)
	{
		leftUp = posValue(leftUp, _thumbR._angle);
		rightUp = posValue(rightUp, _thumbR._angle);
		rightDown = posValue(rightDown, _thumbR._angle);
		leftDown = posValue(leftDown, _thumbR._angle);

		leftUp = VECTOR2(leftUp.x - (2 * _thumbR._size) - (_thumbR._angle * 2), leftUp.y - (2 * _thumbR._size));
		rightUp = VECTOR2(rightUp.x + (2 * _thumbR._size) - (_thumbR._angle * 2), rightUp.y - (2 * _thumbR._size));
	}


	DrawRotaGraph((_finger.posRight.x + _finger.w / 2) - sin(PI * 2 / 300 * _count) * 5.0f, 
		(_finger.posRight.y + _finger.h / 2) - sin(PI * 2 / 300 * _count) * 5.0f + _thumbR._fadeout,
		1, 0, IMAGE_ID("image/rightHand.png"), true);

	DrawModiGraph(leftUp.x - sin(PI * 2 / 300 * _count) * 5.0f, leftUp.y - sin(PI * 2 / 300 * _count) * 5.0f + _thumbR._fadeout,
		rightUp.x - sin(PI * 2 / 300 * _count) * 5.0f, rightUp.y - sin(PI * 2 / 300 * _count) * 5.0f + _thumbR._fadeout,
		rightDown.x - sin(PI * 2 / 300 * _count) * 5.0f, rightDown.y - sin(PI * 2 / 300 * _count) * 5.0f + _thumbR._fadeout,
		leftDown.x - sin(PI * 2 / 300 * _count) * 5.0f, leftDown.y - sin(PI * 2 / 300 * _count) * 5.0f + _thumbR._fadeout, IMAGE_ID("image/rightFinger.png"), true);
	if (_finger._nowNumber <= 1)
	{
		_thumbR._fadeout += 5.0f;
	}
	if (_finger._nowNumber <= 0)
	{
		_thumbL._fadeout += 5.0f;
	}

	if (_finger._playerNumber == nextNumber)
	{
		_countOya++;
		if ((_countOya / 50 % 2) == 0)
		{
			DrawRotaGraph(SCREEN_CENTER_X, 40, 0.6f, 0, IMAGE_ID("image/youOya.png"), true);
		}
		DrawRotaGraph(80 + 70, 50, 0.7f, 0, _num[_finger._setValue], true);
	}
	//DrawBox(100 + (50 * _finger._playerNumber), 250, 125 + (50 * _finger._playerNumber), 300, 0xffff00, true);

	if (lpGameTask.GetMoveAnimationFlag())
	{
		DrawRotaGraph(SCREEN_CENTER_X, SCREEN_SIZE_Y - 130, 0.7f, 0.0f, _numW[_finger._number], true);
	}

	//DrawFormatString(100 + (50 * _finger._playerNumber), 230, 0x000000, "�w:%d", _finger._number);
	//DrawFormatString(100 + (50 * _finger._playerNumber), 310, 0x000000, "��:%d", _finger._nowNumber);

	//DrawFormatString(600, 400, 0x000000, "%d", nextNumber);

	_alpha = _finger._pushCount * 5;
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, _alpha);
	DrawRotaGraph(SCREEN_CENTER_X, 150, 0.7f, 0.0f, IMAGE_ID("image/kakegoe.png"), true);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, _alpha);
}

void Player::PlaySounds()
{
	if (k._yuF)
	{
		StopSoundMem(k._ma);
		StopSoundMem(k._bi);
		StopSoundMem(k._su);
		if (k._countYu <= 0)
		{
			PlaySoundMem(k._yu, DX_PLAYTYPE_BACK);
		}
		k._countYu++;
		k._yuF = false;
	}
	if (k._biF)
	{
		StopSoundMem(k._yu);
		StopSoundMem(k._ma);
		StopSoundMem(k._su);
		if (k._countBi <= 0)
		{
			PlaySoundMem(k._bi, DX_PLAYTYPE_BACK);
		}
		k._countBi++;
		k._biF = false;
	}
	if (k._suF)
	{
		StopSoundMem(k._yu);
		StopSoundMem(k._bi);
		StopSoundMem(k._ma);
		if (k._countSu <= 0)
		{
			PlaySoundMem(k._su, DX_PLAYTYPE_BACK);
		}
		k._countSu++;
		k._suF = false;
	}
	if (k._maF)
	{
		StopSoundMem(k._yu);
		StopSoundMem(k._bi);
		StopSoundMem(k._su);
		if (k._countMa <= 0)
		{
			PlaySoundMem(k._ma, DX_PLAYTYPE_BACK);
			k._numFalg = true;
		}
		k._countMa++;
		k._maF = false;
	}

	// �����̔�������ValueComparison()�ɂ����B���݂܂���

	if (_finger._pushCount < 40 / 4)
	{
		k._countYu = 0;
		k._countBi = 0;
		k._countSu = 0;
		k._countMa = 0;
	}
}

void Player::ValueComparison()
{
	if (GetRand(2) == 0)
	{
		_waitTime++;
	}
	if (_waitTime > 10)
	{
		if (k._numFalg && k._countNum <= 0)
		{
			PlaySoundMem(k._numVoice[_finger._setValue], DX_PLAYTYPE_BACK);
			k._countNum++;
			k._numFalg = false;
		}
	}
	if ((KeyMng::GetInstance().trgKey[P1_ENTER] || _waitTime > 90) && _changeFlag)
	{
		KeyMng::GetInstance().trgKey[P1_ENTER] = false;
		_waitTime = 0;
		TurnNext();
	}
	/* �w�肵���w�̑����ƍ��v�l�������Ȃ�� */
	else if (_finger._nowNumber > 0 && !_changeFlag)
	{
		auto fingerValue = GameMain::GetInstance().GetNumberValue();

		if (_finger._setValue == fingerValue)
		{
			--_finger._nowNumber;

			if (_finger._nowNumber <= 0)
			{
				GameMain::GetInstance().SubPlayerNumber(1);
			}
		}
		_changeFlag = true;
	}

}

void Player::TurnNext()
{
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	GameMain::GetInstance().SetStopMotion(false);
	GameMain::GetInstance().SetNextNumber((nextNumber >= GameMain::GetInstance().GetGameRule()._playerMax ? 1 :_finger._playerNumber + 1));
	_finger._setValue = 0;
	_finger._pushCount = 0;
	_changeFlag = false;
	//_number = 0;
	k._countYu = 0;
	k._countBi = 0;
	k._countSu = 0;
	k._countMa = 0;
	k._countNum = 0;
	k._yuF = false;
	k._biF = false;
	k._suF = false;
	k._maF = false;
	k._numFalg = false;
}

void Player::ClearAngle()
{
}

const int& Player::GetNumber()
{
	return _finger._number;
}

const int& Player::GetFingerNumber()
{
	return _finger._nowNumber;
}

const int& Player::GetFingerValue()
{
	return _finger._setValue;
}

const bool& Player::GetNextFlag()
{
	return _nextFlag;
}
