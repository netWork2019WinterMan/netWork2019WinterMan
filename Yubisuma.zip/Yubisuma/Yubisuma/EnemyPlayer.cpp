#include "EnemyPlayer.h"
#include "KeyMng.h"
#include "DxLib.h"
#include "ImageMng.h"
#include "AffineTransformation.h"
#include "GameTask.h"
#include <cmath>

EnemyPlayer::EnemyPlayer(VECTOR2 posLeft, VECTOR2 posRight, OYAKO oyako, int playerNumber)
{
	_finger._pushCount = 0;
	_finger._oyako = oyako;
	_finger._playerNumber = playerNumber;
	_finger.posLeft = posLeft;
	_finger.posRight = posRight;
	_handle = IMAGE_ID("image/leftHand.png");
	_finger.w = 256, _finger.h = 256;

	_thumbL.posLeft = VECTOR2(_finger.posLeft.x + 110, _finger.posLeft.y + 20, 1);
	_thumbR.posRight = VECTOR2(_finger.posRight.x + 80, _finger.posRight.y + 20, 1);

	_thumbL.w = 65, _thumbL.h = 140;
	_thumbR.w = 65, _thumbR.h = 140;

	_thumbR._fadeout = 0.0f;
	_thumbL._fadeout = 0.0f;

	_mat = std::make_shared<AffineTransformation>(_thumbL.posLeft);

	_count = 0;

	k._yu = SOUND_ID("sound/yu.wav");
	k._bi = SOUND_ID("sound/bi.wav");
	k._su = SOUND_ID("sound/su.wav");
	k._ma = SOUND_ID("sound/ma.wav");
	k._yuF = false;
	k._biF = false;
	k._suF = false;
	k._maF = false;
	k._countYu = 0;
	k._countYu = 0;
	k._countYu = 0;
	k._countYu = 0;

	k._numVoice[0] = SOUND_ID("sound/0.wav");
	k._numVoice[1] = SOUND_ID("sound/1.wav");
	k._numVoice[2] = SOUND_ID("sound/2.wav");
	k._numVoice[3] = SOUND_ID("sound/3.wav");
	k._numVoice[4] = SOUND_ID("sound/4.wav");
	k._numVoice[5] = SOUND_ID("sound/5.wav");
	k._numVoice[6] = SOUND_ID("sound/6.wav");
	k._numVoice[7] = SOUND_ID("sound/7.wav");
	k._numVoice[8] = SOUND_ID("sound/8.wav");

	k._numFalg = false;

	LoadDivGraph("image/numW.png", 11, 11, 1, 100, 100, _numW);
	LoadDivGraph("image/num.png", 11, 11, 1, 100, 100, _num);
}

EnemyPlayer::~EnemyPlayer()
{
}

void EnemyPlayer::Update()
{

	if (_changeFlag)
	{
		return;
	}

	_nextFlag = false;
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	if (GameMain::GetInstance().GetStopMotion())
	{
		return;
	}
	if (_finger._playerNumber == nextNumber && _finger._nowNumber <= 0)
	{
		TurnNext();
		return;
	}

	////////////////////////////

	//NetWork�Ŏ󂯓n��

	////////////////////////////

	_finger._number = _thumbL._number + _thumbR._number;

	if (_finger._pushCount >= 40 / 4 && _finger._pushCount < (40 / 4) * 2)
	{
		k._yuF = true;
	}
	else if (_finger._pushCount >= (40 / 4) * 2 && _finger._pushCount < (40 / 4) * 3)
	{
		k._biF = true;
	}
	else if (_finger._pushCount >= (40 / 4) * 3 && _finger._pushCount < (40 / 4) * 4)
	{
		k._suF = true;
	}
	else if (_finger._pushCount >= (40 / 4) * 4)
	{
		k._maF = true;
	}
	//DrawFormatString(100, 100, 0xffffff, "%f", _finger._pushCount);
	PlaySounds();
}

void EnemyPlayer::Draw()
{
	auto posValue = [&](const VECTOR2& pos, const float& angle) {
		VECTOR2 p;
		p = _mat->Rotation(VECTOR2(1.0f, pos.y, pos.z), angle);
		p.x = pos.x;
		return p;
	};
	auto& nextNumber = GameMain::GetInstance().GetNextNumber();

	_mat->SetPos(_thumbL.posLeft);

	if (_finger._playerNumber == nextNumber)
	{
		DrawRotaGraph(80 + 70, 50, 0.7f, 0, _num[_finger._setValue], true);
	}

	if (_finger._playerNumber == 3)
	{
		// �E�̓G
		_sinC._count1++;
		// �E��
		DrawRotaGraphF(SCREEN_SIZE_X - 100 + _thumbR._fadeout, SCREEN_CENTER_Y - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 3.5f, 0, IMAGE_ID("image/en_hand.png"), true);

		_thumbR._pos = VECTOR2(SCREEN_SIZE_X - 75, SCREEN_CENTER_Y - 17 - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 1);
		//_mat->SetPos(pos);
		//auto vec = posValue(pos, _finger._angle);
		DrawRotaGraphF(_thumbR._pos.x + _thumbR._fadeout, _thumbR._pos.y, 3.5f, (-90 + _thumbR._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);

		// ����
		DrawRotaGraphF(SCREEN_SIZE_X - 70 + _thumbL._fadeout, SCREEN_CENTER_Y + 120 - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 4.2f, 0, IMAGE_ID("image/en_hand1.png"), true);

		_thumbL._pos = VECTOR2(SCREEN_SIZE_X - 41, SCREEN_CENTER_Y + 99 - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 1);

		DrawRotaGraphF(_thumbL._pos.x + _thumbL._fadeout, _thumbL._pos.y, 4.2f, (-90 + _thumbL._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);
		if (_finger._nowNumber <= 1)
		{
			_thumbL._fadeout += 5;
		}
		if (_finger._nowNumber <= 0)
		{
			_thumbR._fadeout += 5;
		}
	}

	if (_finger._playerNumber == 4)
	{
		// ���̓G
		_sinC._count2++;
		// �E��
		DrawRotaGraphF(100 + _thumbR._fadeout, SCREEN_CENTER_Y - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 3.5f, 0, IMAGE_ID("image/en_hand_miror.png"), true);
		DrawRotaGraphF(75 + _thumbR._fadeout, SCREEN_CENTER_Y - 17 - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 3.5f, (90 - _thumbR._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);


		// ����
		DrawRotaGraphF(70 + _thumbL._fadeout, SCREEN_CENTER_Y + 120 - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 4.2f, 0, IMAGE_ID("image/en_hand1_miror.png"), true);
		DrawRotaGraphF(41 + _thumbL._fadeout, SCREEN_CENTER_Y + 99 - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 4.2f, (90 - _thumbL._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);

		if (_finger._nowNumber <= 1)
		{
			_thumbL._fadeout -= 5;
		}
		if (_finger._nowNumber <= 0)
		{
			_thumbR._fadeout -= 5;
		}
	}

	if (_finger._playerNumber == 2)
	{
		// ��
		_sinC._count3++;
		// �E��
		DrawRotaGraphF(SCREEN_CENTER_X - 40, SCREEN_CENTER_Y - 10 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _thumbR._size), 0, IMAGE_ID("image/en_handFront.png"), true);
		DrawRotaGraphF(SCREEN_CENTER_X - 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _thumbR._size), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		if (_finger._nowNumber >= 1)
		{
			DrawRotaGraphF(SCREEN_CENTER_X - 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f - ((_thumbR._angle * 0.08f) * 2), (3 + _thumbR._size) + (_thumbR._size <= -3.0f ? 0 : (_thumbR._angle * 0.005f)), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		}

		// ����
		DrawRotaGraphF(SCREEN_CENTER_X + 40, SCREEN_CENTER_Y - 10 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _thumbL._size), 0, IMAGE_ID("image/en_handFront_miror.png"), true);
		DrawRotaGraphF(SCREEN_CENTER_X + 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _thumbL._size), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		if (_finger._nowNumber >= 2)
		{
			DrawRotaGraphF(SCREEN_CENTER_X + 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f - ((_thumbL._angle * 0.08f) * 2), (3 + _thumbL._size) + (_thumbL._size <= -3.0f ? 0 : (_thumbL._angle * 0.005f)), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		}

		if (_finger._nowNumber <= 1)
		{
			(_thumbL._size > -3.0f ? _thumbL._size -= 0.05f : 0);
			_thumbL._angle = 0.0f;
		}
		if (_finger._nowNumber <= 0)
		{
			(_thumbR._size > -3.0f ? _thumbR._size -= 0.05f : 0);
			_thumbR._angle = 0.0f;
		}
	}
}

void EnemyPlayer::PlaySounds()
{
	if (k._yuF)
	{
		StopSoundMem(k._ma);
		StopSoundMem(k._bi);
		StopSoundMem(k._su);
		if (k._countYu <= 0)
		{
			PlaySoundMem(k._yu, DX_PLAYTYPE_BACK);
		}
		k._countYu++;
		k._yuF = false;
	}
	if (k._biF)
	{
		StopSoundMem(k._yu);
		StopSoundMem(k._ma);
		StopSoundMem(k._su);
		if (k._countBi <= 0)
		{
			PlaySoundMem(k._bi, DX_PLAYTYPE_BACK);
		}
		k._countBi++;
		k._biF = false;
	}
	if (k._suF)
	{
		StopSoundMem(k._yu);
		StopSoundMem(k._bi);
		StopSoundMem(k._ma);
		if (k._countSu <= 0)
		{
			PlaySoundMem(k._su, DX_PLAYTYPE_BACK);
		}
		k._countSu++;
		k._suF = false;
	}
	if (k._maF)
	{
		StopSoundMem(k._yu);
		StopSoundMem(k._bi);
		StopSoundMem(k._su);
		if (k._countMa <= 0)
		{
			PlaySoundMem(k._ma, DX_PLAYTYPE_BACK);
			k._numFalg = true;
		}
		k._countMa++;
		k._maF = false;
	}

	// �����̔�������ValueComparison()�ɂ����B���݂܂���

	if (_finger._pushCount < 40 / 4)
	{
		k._countYu = 0;
		k._countBi = 0;
		k._countSu = 0;
		k._countMa = 0;
	}
}

void EnemyPlayer::ValueComparison()
{
	if (GetRand(2) == 0)
	{
		_waitTime++;
	}
	if (_waitTime > 10)
	{
		if (k._numFalg && k._countNum <= 0)
		{
			PlaySoundMem(k._numVoice[_finger._setValue], DX_PLAYTYPE_BACK);
			k._countNum++;
			k._numFalg = false;
		}
	}
	if ((KeyMng::GetInstance().trgKey[P1_ENTER] || _waitTime > 90) && _changeFlag)
	{
		KeyMng::GetInstance().trgKey[P1_ENTER] = false;
		_waitTime = 0;
		TurnNext();
	}
	/* �w�肵���w�̑����ƍ��v�l�������Ȃ�� */
	else if (_finger._nowNumber > 0 && !_changeFlag)
	{
		auto fingerValue = GameMain::GetInstance().GetNumberValue();

		if (_finger._setValue == fingerValue)
		{
			--_finger._nowNumber;

			if (_finger._nowNumber <= 0)
			{
				GameMain::GetInstance().SubPlayerNumber(1);
			}
		}
		_changeFlag = true;
	}

}

void EnemyPlayer::TurnNext()
{
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	GameMain::GetInstance().SetStopMotion(false);
	GameMain::GetInstance().SetNextNumber((nextNumber >= GameMain::GetInstance().GetGameRule()._playerMax ? 1 : _finger._playerNumber + 1));
	_finger._setValue = 0;
	_finger._pushCount = 0;
	_changeFlag = false;
	//_number = 0;
	k._countYu = 0;
	k._countBi = 0;
	k._countSu = 0;
	k._countMa = 0;
	k._countNum = 0;
	k._yuF = false;
	k._biF = false;
	k._suF = false;
	k._maF = false;
	k._numFalg = false;
}

void EnemyPlayer::ClearAngle()
{
}

const int& EnemyPlayer::GetNumber()
{
	return _finger._number;
}

const int& EnemyPlayer::GetFingerNumber()
{
	return _finger._nowNumber;
}

const int& EnemyPlayer::GetFingerValue()
{
	return _finger._setValue;
}

const bool& EnemyPlayer::GetNextFlag()
{
	return _nextFlag;
}
