#include "CPU.h"
#include "KeyMng.h"
#include "ImageMng.h"
#include "DxLib.h"


CPU::CPU(OYAKO oyako, int playerNumber)
{
	_finger._oyako = oyako;
	_finger._playerNumber = playerNumber;

	_thumbL._fadeout = 0.0f;
	_thumbR._fadeout = 0.0f;
	_mat = std::make_shared<AffineTransformation>();

	LoadDivGraph("image/numW.png", 11, 11, 1, 100, 100, _numW);
	LoadDivGraph("image/num.png", 11, 11, 1, 100, 100, _num);

	if (_finger._playerNumber == 2)
	{
		_k._yu = SOUND_ID("sound/yu_en1.wav");
		_k._bi = SOUND_ID("sound/bi_en1.wav");
		_k._su = SOUND_ID("sound/su_en1.wav");
		_k._ma = SOUND_ID("sound/ma_en1.wav");

		_k._numVoice[0] = SOUND_ID("sound/0_en1.wav");
		_k._numVoice[1] = SOUND_ID("sound/1_en1.wav");
		_k._numVoice[2] = SOUND_ID("sound/2_en1.wav");
		_k._numVoice[3] = SOUND_ID("sound/3_en1.wav");
		_k._numVoice[4] = SOUND_ID("sound/4_en1.wav");
		_k._numVoice[5] = SOUND_ID("sound/5_en1.wav");
		_k._numVoice[6] = SOUND_ID("sound/6_en1.wav");
		_k._numVoice[7] = SOUND_ID("sound/7_en1.wav");
		_k._numVoice[8] = SOUND_ID("sound/8_en1.wav");
	}
	if (_finger._playerNumber == 3)
	{
		_k._yu = SOUND_ID("sound/yu_en2.wav");
		_k._bi = SOUND_ID("sound/bi_en2.wav");
		_k._su = SOUND_ID("sound/su_en2.wav");
		_k._ma = SOUND_ID("sound/ma_en2.wav");

		_k._numVoice[0] = SOUND_ID("sound/0_en2.wav");
		_k._numVoice[1] = SOUND_ID("sound/1_en2.wav");
		_k._numVoice[2] = SOUND_ID("sound/2_en2.wav");
		_k._numVoice[3] = SOUND_ID("sound/3_en2.wav");
		_k._numVoice[4] = SOUND_ID("sound/4_en2.wav");
		_k._numVoice[5] = SOUND_ID("sound/5_en2.wav");
		_k._numVoice[6] = SOUND_ID("sound/6_en2.wav");
		_k._numVoice[7] = SOUND_ID("sound/7_en2.wav");
		_k._numVoice[8] = SOUND_ID("sound/8_en2.wav");
	}

	if (_finger._playerNumber == 4)
	{
		_k._yu = SOUND_ID("sound/yu_en3.wav");
		_k._bi = SOUND_ID("sound/bi_en3.wav");
		_k._su = SOUND_ID("sound/su_en3.wav");
		_k._ma = SOUND_ID("sound/ma_en3.wav");

		_k._numVoice[0] = SOUND_ID("sound/0_en3.wav");
		_k._numVoice[1] = SOUND_ID("sound/1_en3.wav");
		_k._numVoice[2] = SOUND_ID("sound/2_en3.wav");
		_k._numVoice[3] = SOUND_ID("sound/3_en3.wav");
		_k._numVoice[4] = SOUND_ID("sound/4_en3.wav");
		_k._numVoice[5] = SOUND_ID("sound/5_en3.wav");
		_k._numVoice[6] = SOUND_ID("sound/6_en3.wav");
		_k._numVoice[7] = SOUND_ID("sound/7_en3.wav");
		_k._numVoice[8] = SOUND_ID("sound/8_en3.wav");
	}
}

CPU::CPU()
{
}

CPU::~CPU()
{
}

void CPU::Update()
{
	_setAnim = false;
	lpGameTask.SetMoveAnimationFlag(_setAnim);
	if (_changeFlag || GameMain::GetInstance().GetNowPlayer() <= 1)
	{
		MoveAnimation();
		return;
	}

	if (GameMain::GetInstance().GetStopMotion())
	{
		MoveAnimation();
		return;
	}
	_thumbR._angle = 0.0f;
	_thumbL._angle = 0.0f;

	_nextFlag = false;
	auto nextNumber = GameMain::GetInstance().GetNextNumber();


	if (_finger._playerNumber == nextNumber && _finger._nowNumber <= 0)
	{
		TurnNext();
		return;
	}
	if (GameMain::GetInstance().GetNextNumber() == _finger._playerNumber)
	{
		int randomCount = GetRand(6);
		if (_finger._pushCount >= MAX_TIME)
		{
			_nextFlag = true;
		}
		if (randomCount <= 5)
		{
			(_finger._pushCount < MAX_TIME ? _finger._pushCount++ : 0);
			/*if (_finger._number >= 1)
			{
				(_thumbR._pushCount < MAX_TIME ? _thumbR._pushCount++ : 0);
			}
			if (_finger._number >= 2)
			{
				(_thumbL._pushCount < MAX_TIME ? _thumbL._pushCount++ : 0);
			}*/
		}
		else
		{
			(_finger._pushCount > 0 ? _finger._pushCount-- : 0);
		}
		_finger._setValue = GetRand(GameMain::GetInstance().GetFingerValue());
	}
	int randomCount = GetRand(6);
	if (_finger._pushCount >= MAX_TIME)
	{
		_nextFlag = true;
	}
	/*if (randomCount <= 5)
	{
		(_thumbR._angle > -90.0f ? _thumbR._angle -= 2.0f : 0);
		(_thumbL._angle > -90.0f ? _thumbL._angle -= 2.0f : 0);

	}
	else
	{
		(_thumbR._pushCount > 0 ? _thumbR._pushCount-- : 0);
		(_thumbL._pushCount > 0 ? _thumbL._pushCount-- : 0);

		(_thumbR._angle < 0 ? _thumbR._angle += 2.0f : 0);
		(_thumbL._angle < 0 ? _thumbL._angle += 2.0f : 0);

	}*/
	if (_finger._nowNumber > 1)
	{
		_finger._number = GetRand(2);
	}
	else if (_finger._nowNumber > 0)
	{
		_finger._number = GetRand(1);
	}
	else
	{
		_finger._number = 0;
	}

	if (_finger._pushCount >= 40 / 4 && _finger._pushCount < (40 / 4) * 2)
	{
		_k._yuF = true;
	}
	else if (_finger._pushCount >= (40 / 4) * 2 && _finger._pushCount < (40 / 4) * 3)
	{
		_k._biF = true;
	}
	else if (_finger._pushCount >= (40 / 4) * 3 && _finger._pushCount < (40 / 4) * 4)
	{
		_k._suF = true;
	}
	else if (_finger._pushCount >= (40 / 4) * 4)
	{
		_k._maF = true;
	}
	PlaySounds();
}

void CPU::PlaySounds()
{
	if (_k._yuF)
	{
		StopSoundMem(_k._ma);
		StopSoundMem(_k._bi);
		StopSoundMem(_k._su);
		if (_k._countYu <= 0)
		{
			PlaySoundMem(_k._yu, DX_PLAYTYPE_BACK);
		}
		_k._countYu++;
		_k._yuF = false;
	}
	if (_k._biF)
	{
		StopSoundMem(_k._yu);
		StopSoundMem(_k._ma);
		StopSoundMem(_k._su);
		if (_k._countBi <= 0)
		{
			PlaySoundMem(_k._bi, DX_PLAYTYPE_BACK);
		}
		_k._countBi++;
		_k._biF = false;
	}
	if (_k._suF)
	{
		StopSoundMem(_k._yu);
		StopSoundMem(_k._bi);
		StopSoundMem(_k._ma);
		if (_k._countSu <= 0)
		{
			PlaySoundMem(_k._su, DX_PLAYTYPE_BACK);
		}
		_k._countSu++;
		_k._suF = false;
	}
	if (_k._maF)
	{
		StopSoundMem(_k._yu);
		StopSoundMem(_k._bi);
		StopSoundMem(_k._su);
		if (_k._countMa <= 0)
		{
			PlaySoundMem(_k._ma, DX_PLAYTYPE_BACK);
			_k._numFalg = true;
		}
		_k._countMa++;
		_k._maF = false;
	}

	// �����̔�������ValueComparison()�ɂ����B���݂܂���

	if (_finger._pushCount < 40 / 4)
	{
		_k._countYu = 0;
		_k._countBi = 0;
		_k._countSu = 0;
		_k._countMa = 0;
	}
}

void CPU::Draw()
{
	auto& nextNumber = GameMain::GetInstance().GetNextNumber();
	auto posValue = [&](const VECTOR2& pos, const float& angle) {
		VECTOR2 p;
		p = _mat->Rotation(VECTOR2(pos.x, pos.y, pos.z), angle);
		p.z = pos.z;
		return p;
	};
	

	if (_finger._playerNumber == nextNumber)
	{
		DrawRotaGraph(80 + 70, 50, 0.7f, 0, _num[_finger._setValue], true);
	}
	//DrawBox(100 + (50 * _finger._playerNumber), 250, 125 + (50 * _finger._playerNumber), 300, 0xffff00, true);

	//DrawFormatString(100 + (50 * _finger._playerNumber), 230, 0x000000, "�w:%d", _finger._number);
	//DrawFormatString(100 + (50 * _finger._playerNumber), 310, 0x000000, "��:%d", _finger._nowNumber);

	//DrawFormatString(600, 400, 0x000000, "%d", nextNumber);

	if (_finger._playerNumber == 3)
	{
		// �E�̓G
		_sinC._count1++;
		// �E��
		DrawRotaGraphF(SCREEN_SIZE_X - 100 + _thumbR._fadeout, SCREEN_CENTER_Y - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 3.5f, 0, IMAGE_ID("image/en_hand.png"), true);

		_thumbR._pos = VECTOR2(SCREEN_SIZE_X - 75, SCREEN_CENTER_Y - 17 - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 1);
		//_mat->SetPos(pos);
		//auto vec = posValue(pos, _finger._angle);
		DrawRotaGraphF(_thumbR._pos.x + _thumbR._fadeout, _thumbR._pos.y, 3.5f, (-90 + _thumbR._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);

		// ����
		DrawRotaGraphF(SCREEN_SIZE_X - 70 + _thumbL._fadeout, SCREEN_CENTER_Y + 120 - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 4.2f, 0, IMAGE_ID("image/en_hand1.png"), true);

		_thumbL._pos = VECTOR2(SCREEN_SIZE_X - 41, SCREEN_CENTER_Y + 99 - sin(PI * 2 / 300 * _sinC._count1) * 5.0f, 1);

		DrawRotaGraphF(_thumbL._pos.x + _thumbL._fadeout, _thumbL._pos.y, 4.2f, (-90 + _thumbL._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);
		if (_finger._nowNumber <= 1)
		{
			_thumbL._fadeout += 5;
		}
		if (_finger._nowNumber <= 0)
		{
			_thumbR._fadeout += 5;
		}
	}

	if (_finger._playerNumber == 4)
	{
		// ���̓G
		_sinC._count2++;
		// �E��
		DrawRotaGraphF(100 + _thumbR._fadeout, SCREEN_CENTER_Y - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 3.5f, 0, IMAGE_ID("image/en_hand_miror.png"), true);
		DrawRotaGraphF(75 + _thumbR._fadeout, SCREEN_CENTER_Y - 17 - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 3.5f, (90 - _thumbR._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);
		
		
		// ����
		DrawRotaGraphF(70 + _thumbL._fadeout, SCREEN_CENTER_Y + 120 - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 4.2f, 0, IMAGE_ID("image/en_hand1_miror.png"), true);
		DrawRotaGraphF(41 + _thumbL._fadeout, SCREEN_CENTER_Y + 99 - sin(PI * 2 / 300 * _sinC._count2) * 5.0f, 4.2f, (90 - _thumbL._angle) * (PI / 180), IMAGE_ID("image/Oya_finger.png"), true);

		if (_finger._nowNumber <= 1)
		{
			_thumbL._fadeout-= 5;
		}
		if (_finger._nowNumber <= 0)
		{
			_thumbR._fadeout -= 5;
		}
	}

	if (_finger._playerNumber == 2)
	{
		// ��
		_sinC._count3++;
		// �E��
		DrawRotaGraphF(SCREEN_CENTER_X - 40, SCREEN_CENTER_Y - 10 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _thumbR._size), 0, IMAGE_ID("image/en_handFront.png"), true);
		DrawRotaGraphF(SCREEN_CENTER_X - 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _thumbR._size), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		if (_finger._nowNumber >= 1)
		{
			DrawRotaGraphF(SCREEN_CENTER_X - 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f - ((_thumbR._angle * 0.08f) * 2), (3 + _thumbR._size) + (_thumbR._size <= -3.0f ? 0 : (_thumbR._angle * 0.005f)), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		}
		
		// ����
		DrawRotaGraphF(SCREEN_CENTER_X + 40, SCREEN_CENTER_Y - 10 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _thumbL._size), 0, IMAGE_ID("image/en_handFront_miror.png"), true);
		DrawRotaGraphF(SCREEN_CENTER_X + 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f, (3 + _thumbL._size), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		if (_finger._nowNumber >= 2)
		{
			DrawRotaGraphF(SCREEN_CENTER_X + 22, SCREEN_CENTER_Y - 23 - sin(PI * 2 / 300 * _sinC._count3) * 5.0f - ((_thumbL._angle * 0.08f) * 2), (3 + _thumbL._size) + (_thumbL._size <= -3.0f ? 0 : (_thumbL._angle * 0.005f)), 0, IMAGE_ID("image/GJ_handFrontOya.png"), true);
		}

		if(_finger._nowNumber <= 1)
		{
			(_thumbL._size > -3.0f ? _thumbL._size -= 0.05f : 0);
			_thumbL._angle = 0.0f;
		}
		if (_finger._nowNumber <= 0)
		{
			(_thumbR._size > -3.0f ? _thumbR._size -= 0.05f : 0);
			_thumbR._angle = 0.0f;
		}
	}
}

void CPU::ClearAngle()
{
	_thumbR._angle = 0.0f;
	_thumbL._angle = 0.0f;

	_thumbR._pushCount = 0;
	_thumbL._pushCount = 0;

}

void CPU::ValueComparison()
{
	if (GetRand(2) == 0)
	{
		_waitTime++;
	}
	if (_waitTime > 10)
	{
		if (_k._numFalg && _k._countNum <= 0)
		{
			PlaySoundMem(_k._numVoice[_finger._setValue], DX_PLAYTYPE_BACK);
			_k._countNum++;
			_k._numFalg = false;
		}
	}
	if ((KeyMng::GetInstance().trgKey[P1_ENTER] || _waitTime > 60) && _changeFlag)
	{
		KeyMng::GetInstance().trgKey[P1_ENTER] = false;
		_waitTime = 0;
		TurnNext();
	}
	/* �w�肵���w�̑����ƍ��v�l�������Ȃ�� */
	else if (_finger._nowNumber > 0 && !_changeFlag)
	{
		auto fingerValue = GameMain::GetInstance().GetNumberValue();

		if (_finger._setValue == fingerValue)
		{
			--_finger._nowNumber;
			if (_finger._nowNumber <= 0)
			{
				GameMain::GetInstance().SubPlayerNumber(1);
			}
		}
		_changeFlag = true;

	}
}

void CPU::TurnNext()
{
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	GameMain::GetInstance().SetStopMotion(false);
	GameMain::GetInstance().SetNextNumber((nextNumber >= GameMain::GetInstance().GetGameRule()._playerMax ? 1 : _finger._playerNumber + 1));
	GameMain::GetInstance().SetAngleReset(true);
	_finger._setValue = 0;
	_finger._pushCount = 0;
	_finger._angle = 0.0f;
	_changeFlag = false;
	_nextFlag = false;
	ClearAngle();

	_k._countYu = 0;
	_k._countBi = 0;
	_k._countSu = 0;
	_k._countMa = 0;
	_k._countNum = 0;
	_k._yuF = false;
	_k._biF = false;
	_k._suF = false;
	_k._maF = false;
	_k._numFalg = false;
}

void CPU::MoveAnimation()
{
	if (_finger._number >= 1)
	{
		(_thumbR._angle < 90.0f ? _thumbR._angle += 9.0f : 0);

	}
	if (_finger._number >= 2)
	{
		(_thumbL._angle < 90.0f ? _thumbL._angle += 9.0f : 0);
	}

	_setAnim = true;
	lpGameTask.SetMoveAnimationFlag(_setAnim);
	if (_finger._playerNumber == 2)
	{
		DrawRotaGraph(SCREEN_CENTER_X, SCREEN_CENTER_Y + 50, 0.5f, 0, _numW[_finger._number], true);
	}
	if (_finger._playerNumber == 3)
	{
		DrawRotaGraph(SCREEN_SIZE_X - 170, SCREEN_CENTER_Y + 100, 0.7f, 0, _numW[_finger._number], true);
	}
	if (_finger._playerNumber == 4)
	{
		DrawRotaGraph(170, SCREEN_CENTER_Y + 100, 0.7f, 0, _numW[_finger._number], true);
	}

}

const int& CPU::GetNumber()
{
	return _finger._number;
}

const int& CPU::GetFingerNumber()
{
	return _finger._nowNumber;
}

const int& CPU::GetFingerValue()
{
	return _finger._setValue;
}

const bool& CPU::GetNextFlag()
{
	return _nextFlag;
}
