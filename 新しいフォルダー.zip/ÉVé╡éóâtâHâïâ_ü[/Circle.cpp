#include "Circle.h"
#include "DxLib.h"

Circle::Circle()
{
}

Circle::Circle(VECTOR2 p): _pos(p)
{
	SetHitCheck();
}

Circle::Circle(VECTOR2 p, VECTOR2 startPos, VECTOR2 endPos): _pos(p), _startPos(startPos), _endPos(endPos)
{
	SetHitCheck();
}

void Circle::SetHitCheck()
{
	_hitCheck.left = _pos.x - _size * 2;
	_hitCheck.right = _pos.x + _size * 2;
	_hitCheck.top = _pos.y - _size * 2;
	_hitCheck.bottom = _pos.y + _size * 2;
}

void Circle::SetHitCheck(VECTOR2 pos)
{
	_hitCheck.left = pos.x - _size * 2;
	_hitCheck.right = pos.x + _size * 2;
	_hitCheck.top = pos.y - _size * 2;
	_hitCheck.bottom = pos.y + _size * 2;
}

void Circle::SetCheckFlag(bool flag)
{
	_checkFlag = flag;
}

const bool& Circle::GetCheckFlag()
{
	return _checkFlag;
}

Circle::~Circle()
{
}

const VECTOR2& Circle::GetPos()
{
	return _pos;
}

const VECTOR2& Circle::GetCenterPos()
{
	return _centerPos;
}

void Circle::Update()
{
	_centerPos = VECTOR2((_startPos.x + _endPos.x) / 2, (_startPos.y + _endPos.y) / 2);
	
	auto p = (_endPos - _startPos) / 100;

	while (++_timeCnt < 100)
	{
		_vec.emplace_back(_startPos + (p * _timeCnt));
	}

	if (_startPos.x != 0 && _startPos.y != 0)
	{
		if (_vec.size() > 0)
		{
			for (auto& vec : _vec)
			{
				DrawCircle(vec.x, vec.y, 8, 0xffffff);
			}
		}
	}
}

void Circle::CenterDraw(unsigned int color)
{
	DrawCircle(_centerPos.x, _centerPos.y, _size, color);
}

void Circle::Draw(unsigned int color)
{
	DrawCircle(_pos.x, _pos.y, _size, color);

	if (_startPos.x != 0 && _startPos.y != 0)
	{
		CenterDraw(0xffff00);
	}
}

void Circle::DrawHitBox(unsigned int color)
{
	DrawBox(_hitCheck.left, _hitCheck.top, _hitCheck.right, _hitCheck.bottom, color, true);
}

void Circle::LineDraw(VECTOR2 nextPos)
{
	DrawLine(_pos.x, _pos.y, nextPos.x, nextPos.y, 0xff0000);
}

void Circle::LineCenterDraw(VECTOR2 nextPos)
{
	DrawLine(_centerPos.x, _centerPos.y, nextPos.x, nextPos.y, 0xff0000);
}

void Circle::SetPos(VECTOR2 pos)
{
	_pos = pos;
}

void Circle::SetStartPos(VECTOR2 pos)
{
	_startPos = pos;
}

void Circle::SetEndPos(VECTOR2 pos)
{
	_endPos = pos;
}

bool Circle::GetHitCheck(VECTOR2 pos)
{
	if (pos.x > _hitCheck.left&& pos.x < _hitCheck.right)
	{
		if (pos.y > _hitCheck.top&& pos.y < _hitCheck.bottom)
		{
			return true;
		}
	}

	return false;
}
