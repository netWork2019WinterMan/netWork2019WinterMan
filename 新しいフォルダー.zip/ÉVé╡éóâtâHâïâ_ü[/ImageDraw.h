#pragma once
#include "VECTOR3.h"
#include "ImageMng.h"
#include <memory>

class AffineTransformation;
class ImageDraw
{
public:
	ImageDraw(VECTOR3 pos, VECTOR3 offset, VECTOR3 size, int handle);
	~ImageDraw();

	void Update();
	void Draw();

private:
	struct Image
	{
		VECTOR3 pos;
		VECTOR3 size;
		int handle;
		float angle = 0.0f;
	};
	void Key();

	VECTOR3 _offset;
	VECTOR3 _startPos;
	Image _image;
	int size = 64;

	std::unique_ptr<AffineTransformation> _mat;
};

