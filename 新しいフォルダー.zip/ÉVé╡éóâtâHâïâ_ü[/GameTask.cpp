#include "DxLib.h"
#include "GameTask.h"
#include "ImageMng.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include "MouseMng.h"
#include "Circle.h"


GameTask *GameTask::s_Instance = nullptr;

vector<std::shared_ptr<Circle>> vectors;
vector<std::shared_ptr<Circle>> center;
VECTOR2 vec = VECTOR2(0, 0);
VECTOR2 pos = VECTOR2(0, 0);

void GameTask::Create(void)
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("Template");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);
}

void GameTask::GameUpdate()
{
	// ���݂̃��[�h�ŉ�
	(this->*gMode[currentMode])();
}

void GameTask::GameInit()
{
	DrawString(10, 10, "INIT", 0xffffff);

	//lineVec.push_back(reset);

	//--------------------------------------------------
	// ������
	//--------------------------------------------------
	currentMode = G_INIT;

	currentMode = G_MAIN;

}

void GameTask::GameMain()
{
	DrawString(10, 10, "MAIN", 0xffffff);
	if (_popFlag)
	{
		DrawString(10, 30, "�ړ�", 0xffffff);
		if (_checkFlag)
		{
			DrawString(10, 50, "Hold:On", 0xffffff);
		}
		else
		{
			DrawString(10, 50, "Hold:Off", 0xffffff);
		}
	}
	else
	{
		DrawString(10, 30, "�`��", 0xffffff);

		DrawString(10, 50, "Hold:Off", 0xffffff);
	}

	MouseMng::GetInstance().Update();

	int Mx, My;

	GetMousePoint(&Mx, &My);

	if (!_checkFlag)
	{
		if (MouseMng::GetInstance().trgKey[P1_PUSH])
		{
			for (auto& p : vectors)
			{
				if (_popFlag && p->GetHitCheck(VECTOR2(Mx, My)))
				{
					_checkFlag = true;
					p->SetCheckFlag(_checkFlag);
					break;
				}
			}

			if (_checkFlag)
			{

			}
			else
			{
				_popFlag = false;
				int x, y;
				GetMousePoint(&x, &y);
				vectors.push_back(std::make_shared<Circle>(VECTOR2(x, y), vec, VECTOR2(x, y)));

				/*if (vec.x != 0 && vec.y != 0)
				{
					center.push_back(std::make_shared<Circle>(VECTOR2((vec.x + x) / 2, (vec.y + y) / 2), vec, VECTOR2(x, y)));
				}*/
				vec.x = x;
				vec.y = y;
			}
		}
		else if (MouseMng::GetInstance().trgKey[P1_POP])
		{
			_popFlag = true;
		}
	}
	else
	{
		if (_checkFlag && MouseMng::GetInstance().newKey[P1_PUSH])
		{
			for (auto& p : vectors)
			{
				if (_popFlag && p->GetCheckFlag())
				{
					p->SetPos(VECTOR2(Mx, My));
					break;
				}
			}


			for (int i = 0; i + 1 <= vectors.size(); ++i)
			{
				if (vectors[i]->GetCheckFlag())
				{
					if (i + 1 < vectors.size())
					{
						vectors[i + 1]->SetStartPos(vectors[i]->GetPos());
					}
					vectors[i]->SetEndPos(vectors[i]->GetPos());
				}
			}

		}
		else if (MouseMng::GetInstance().trgKey[P1_POP])
		{
			_checkFlag = false;
			for (auto& p : vectors)
			{
				p->SetCheckFlag(_checkFlag);
			}
		}
	}
	for (int j = 0; j + 1 < vectors.size(); ++j)
	{
		vectors[j]->LineDraw(vectors[j + 1]->GetPos());
	}

	if (vec.x != 0 && vec.y != 0 && !_popFlag)
	{
		DrawLine(vec.x, vec.y, Mx, My, 0xff0000);
	}

	auto end = VECTOR2(0, 0);


	for (auto& p : vectors)
	{
		p->SetHitCheck();
		p->DrawHitBox(0xff00ff);
		p->Update();
		p->Draw();

		if (_popFlag && p->GetHitCheck(vec))
		{
			auto p = 0;
		}
	}
	/*for (auto& c : center)
	{
		c->SetHitCheck();
		c->Draw(0xffff00);
	}*/

	if (CheckHitKey(KEY_INPUT_F1))
	{
		auto SaveGameMain = SaveDrawScreenToPNG(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, "image/screen.png");
	}
}


