#pragma once
#include "VECTOR2.h"
#include <Windows.h>
class Circle
{
public:
	Circle();
	Circle(VECTOR2 p);
	Circle(VECTOR2 p, VECTOR2 startPos, VECTOR2 endPos);

	~Circle();

	const VECTOR2& GetPos();
	const VECTOR2& GetCenterPos();
	void Update();
	void CenterDraw(unsigned int color = 0xffffff);
	void Draw(unsigned int color = 0xffffff);
	void DrawHitBox(unsigned int color = 0xffffff);
	void LineDraw(VECTOR2 nextPos);
	void LineCenterDraw(VECTOR2 nextPos);

	void SetPos(VECTOR2 pos);
	void SetStartPos(VECTOR2 pos);
	void SetEndPos(VECTOR2 pos);

	bool GetHitCheck(VECTOR2 pos);
	void SetHitCheck();
	void SetHitCheck(VECTOR2 pos);

	void SetCheckFlag(bool flag);
	const bool& GetCheckFlag();

private:
	VECTOR2 _pos;
	VECTOR2 _centerPos;
	VECTOR2 _startPos;
	VECTOR2 _endPos;

	RECT _hitCheck;

	bool _checkFlag = false;
	unsigned int _size = 6;
	int _timeCnt = 0;
	std::vector<VECTOR2> _vec;
};

