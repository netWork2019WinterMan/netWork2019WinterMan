#pragma once
#include <cmath>
#include <vector>
class VECTOR2
{
public:
	VECTOR2();
	VECTOR2(int px, int py) : x(px), y(py) {}
	~VECTOR2();
	float x, y;

	// �Εӂ����߂�
	float Magnitude()const
	{
		return sqrt(x * x + y * y);
	}

	//���K��
	VECTOR2 Normalize()const
	{
		auto z = Magnitude();
		return VECTOR2(x / z, y / z);
	}

private:

};
VECTOR2 operator*(const VECTOR2&, const VECTOR2&);
VECTOR2 operator*(const VECTOR2&, const float&);
VECTOR2 operator/(const VECTOR2&, const float&);
VECTOR2 operator-(const VECTOR2&, const VECTOR2&);
VECTOR2 operator+(const VECTOR2&, const VECTOR2&);
