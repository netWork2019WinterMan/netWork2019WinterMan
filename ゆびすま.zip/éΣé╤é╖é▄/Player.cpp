#include "Player.h"
#include "KeyMng.h"
#include "DxLib.h"
#include "ImageMng.h"
#include "AffineTransformation.h"

Player::Player(VECTOR2 posLeft, VECTOR2 posRight, OYAKO oyako, PlayerType playertype, int playerNumber): _playertype(playertype)
{
	_finger._oyako = oyako;
	_finger._playerNumber = playerNumber;
	_finger.posLeft = posLeft;
	_finger.posRight = posRight;
	_handle = IMAGE_ID("image/���̌�.png");
	//GetSoftImageSize(_handle, &w, &h);
	_finger.w = 256, _finger.h = 256;

	_thumb.posLeft = VECTOR2(_finger.posLeft.x + 110, _finger.posLeft.y + 20, 1);
	_thumb.posRight = VECTOR2(_finger.posRight.x + 80, _finger.posRight.y + 20, 1);

	_thumb.w = 65, _thumb.h = 140;

	_mat = std::make_shared<AffineTransformation>(_thumb.posLeft);
}

Player::~Player()
{
}

void Player::Update()
{

	if (_changeFlag)
	{
		return;
	}

	_nextFlag = false;
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	if (GameMain::GetInstance().GetStopMotion())
	{
		return;
	}
	if (_finger._playerNumber == nextNumber && _finger._nowNumber <= 0)
	{
		TurnNext();
		return;
	}
	if (GameMain::GetInstance().GetNextNumber() == _finger._playerNumber)
	{
		if (_finger._pushCount >= MAX_TIME)
		{
			_nextFlag = true;

		}
		if (KeyMng::GetInstance().newKey[P1_ENTER])
		{
			(_finger._pushCount < MAX_TIME ? _finger._pushCount += 3 : 0);
			if (_finger._number > 0)
			{
				(_thumb._angle > -10.0f ? _thumb._angle -= 0.4f : 0);
				(_thumb._size < 6.0f ? _thumb._size += 0.2f : 0);
			}
		}
		else
		{
			(_finger._pushCount > 0 ? _finger._pushCount -= 3 : 0);
			(_thumb._angle < 0 ? _thumb._angle += 0.4f : 0);
			(_thumb._size > 1.0f ? _thumb._size -= 0.2f : 0);

		}
		if (KeyMng::GetInstance().trgKey[P1_RIGHT])
		{
			(_finger._setValue < GameMain::GetInstance().GetFingerValue() ? _finger._setValue++ : 0);
		}
		else if (KeyMng::GetInstance().trgKey[P1_LEFT])
		{
			(_finger._setValue > 0 ? _finger._setValue-- : 0);
		}
	}
	

	if (KeyMng::GetInstance().trgKey[P1_UP])
	{
		(_finger._number < 2 ? _finger._number++ : 0);
	}
	else if (KeyMng::GetInstance().trgKey[P1_DOWN])
	{
		(_finger._number > 0 ? _finger._number-- : 0);
	}

}

void Player::Draw()
{
	auto posValue = [&](const VECTOR2& pos, const float& angle) {
		VECTOR2 p;
		p = _mat->Rotation(VECTOR2(1.0f, pos.y, pos.z), angle);
		p.x = pos.x;
		return p;
	};
	auto& nextNumber = GameMain::GetInstance().GetNextNumber();
	//���e�w����
	auto leftUp = VECTOR2(_thumb.posLeft.x, _thumb.posLeft.y, _thumb.posLeft.z);
	auto rightUp = VECTOR2(_thumb.posLeft.x + _thumb.w, _thumb.posLeft.y, _thumb.posLeft.z);
	auto rightDown = VECTOR2(_thumb.posLeft.x + _thumb.w, _thumb.posLeft.y + _thumb.h, _thumb.posLeft.z);
	auto leftDown = VECTOR2(_thumb.posLeft.x, _thumb.posLeft.y + _thumb.h, _thumb.posLeft.z);

	leftUp = posValue(leftUp, _thumb._angle);
	rightUp = posValue(rightUp, _thumb._angle);
	rightDown = posValue(rightDown, _thumb._angle);
	leftDown = posValue(leftDown, _thumb._angle);

	//����
	DrawModiGraph(_finger.posLeft.x, _finger.posLeft.y,
		_finger.posLeft.x + _finger.w, _finger.posLeft.y,
		_finger.posLeft.x + _finger.w, _finger.posLeft.y + _finger.h,
		_finger.posLeft.x, _finger.posLeft.y + _finger.h, IMAGE_ID("image/���̌�.png"), true);

	DrawModiGraph(leftUp.x - (2 * _thumb._size) + (_thumb._angle * 2), leftUp.y - (2 * _thumb._size),
		rightUp.x + (2 * _thumb._size) + (_thumb._angle * 2), rightUp.y - (2 * _thumb._size),
		rightDown.x, rightDown.y,
		leftDown.x, leftDown.y, IMAGE_ID("image/���̐e�w.png"), true);

	//�E��
	leftUp = VECTOR2(_thumb.posRight.x, _thumb.posRight.y, _thumb.posRight.z);
	rightUp = VECTOR2(_thumb.posRight.x + _thumb.w, _thumb.posRight.y, _thumb.posRight.z);
	rightDown = VECTOR2(_thumb.posRight.x + _thumb.w, _thumb.posRight.y + _thumb.h, _thumb.posRight.z);
	leftDown = VECTOR2(_thumb.posRight.x, _thumb.posRight.y + _thumb.h, _thumb.posRight.z);

	if (_finger._number > 1)
	{
		leftUp = posValue(leftUp, _thumb._angle);
		rightUp = posValue(rightUp, _thumb._angle);
		rightDown = posValue(rightDown, _thumb._angle);
		leftDown = posValue(leftDown, _thumb._angle);

		leftUp = VECTOR2(leftUp.x - (2 * _thumb._size) - (_thumb._angle * 2), leftUp.y - (2 * _thumb._size));
		rightUp = VECTOR2(rightUp.x + (2 * _thumb._size) - (_thumb._angle * 2), rightUp.y - (2 * _thumb._size));
	}

	DrawModiGraph(_finger.posRight.x, _finger.posRight.y,
		_finger.posRight.x + _finger.w, _finger.posRight.y,
		_finger.posRight.x + _finger.w, _finger.posRight.y + _finger.h,
		_finger.posRight.x, _finger.posRight.y + _finger.h, IMAGE_ID("image/�E�̌�.png"), true);

	DrawModiGraph(leftUp.x , leftUp.y,
		rightUp.x,rightUp.y,
		rightDown.x, rightDown.y,
		leftDown.x, leftDown.y, IMAGE_ID("image/�E�̐e�w.png"), true);

	if (_finger._oyako == OYAKO::OYA)
	{
		DrawString(100, 100, "OYA_Player", 0x000000);
	}
	else
	{
		DrawString(300, 100, "KO_Player", 0x000000);
	}

	if (_finger._playerNumber == nextNumber)
	{
		DrawBox(95 + (50 * nextNumber), 245, 130 + (50 * nextNumber), 305, 0xff0000, true);
		DrawFormatString(100 + (50 * nextNumber), 200, 0x000000, "%d", _finger._setValue);
		DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - _finger._pushCount, 0x00ffff, true);
		DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - MAX_TIME, 0x000000, false);
	}
	DrawBox(100 + (50 * _finger._playerNumber), 250, 125 + (50 * _finger._playerNumber), 300, 0xffff00, true);

	DrawFormatString(100 + (50 * _finger._playerNumber), 230, 0x000000, "�w:%d", _finger._number);
	DrawFormatString(100 + (50 * _finger._playerNumber), 310, 0x000000, "��:%d", _finger._nowNumber);

	DrawFormatString(600, 400, 0x000000, "%d", nextNumber);


}

void Player::ValueComparison()
{
	if (GetRand(2) == 0)
	{
		_waitTime++;
	}
	if ((KeyMng::GetInstance().trgKey[P1_ENTER] || _waitTime > 30) && _changeFlag)
	{
		KeyMng::GetInstance().trgKey[P1_ENTER] = false;
		_waitTime = 0;
		TurnNext();
	}
	/* �w�肵���w�̑����ƍ��v�l�������Ȃ�� */
	else if (_finger._nowNumber > 0 && !_changeFlag)
	{
		auto fingerValue = GameMain::GetInstance().GetNumberValue();

		if (_finger._setValue == fingerValue)
		{
			--_finger._nowNumber;

			if (_finger._nowNumber <= 0)
			{
				GameMain::GetInstance().SubPlayerNumber(1);
			}
		}
		_changeFlag = true;

	}

}

void Player::TurnNext()
{
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	GameMain::GetInstance().SetStopMotion(false);
	GameMain::GetInstance().SetNextNumber((nextNumber >= GameMain::GetInstance().GetGameRule()._playerMax ? 1 :_finger._playerNumber + 1));
	_finger._setValue = 0;
	_finger._pushCount = 0;
	_changeFlag = false;
	//_number = 0;

}

const int& Player::GetNumber()
{
	return _finger._number;
}

const int& Player::GetFingerNumber()
{
	return _finger._nowNumber;
}

const int& Player::GetFingerValue()
{
	return _finger._setValue;
}

const bool& Player::GetNextFlag()
{
	return _nextFlag;
}

const PlayerType& Player::GetPlayerType()
{
	return _playertype;
}
