#include "ControlSelectMode.h"
#include "GameTask.h"
#include "ImageMng.h"
#include "KeyMng.h"
#include "Dxlib.h"

ControlSelectMode::ControlSelectMode()
{
	Init();
}

ControlSelectMode::~ControlSelectMode()
{
}

void ControlSelectMode::Init()
{
	box1._UL.x = 50;
	box1._UL.y = SCREEN_CENTER_Y - 50;
	box1._DR.x = SCREEN_CENTER_X - 50;
	box1._DR.y = SCREEN_CENTER_Y + 50;
	box1._scale = 1.0f;

	box2._UL.x = SCREEN_CENTER_X + 50;
	box2._UL.y = SCREEN_CENTER_Y - 50;
	box2._DR.x = SCREEN_SIZE_X - 50;
	box2._DR.y = SCREEN_CENTER_Y + 50;
	box2._scale = 1.0f;

	box3._UL.x = SCREEN_SIZE_X - (SCREEN_CENTER_X / 4) - 65;
	box3._UL.y = (SCREEN_SIZE_Y - 100) - 32.5f;
	box3._DR.x = SCREEN_SIZE_X - (SCREEN_CENTER_X / 4) + 65;
	box3._DR.y = (SCREEN_SIZE_Y - 100) + 32.5f;
	box3._scale = 1.0f;

	_modeFlag = NON_SM;
}

void ControlSelectMode::Update()
{
	GetMousePoint(&mp._posX,&mp._posY);
}

void ControlSelectMode::Draw()
{
	if (mp._posX > box1._UL.x && mp._posY > box1._UL.y && mp._posX < box1._DR.x && mp._posY < box1._DR.y)
	{
		box1._scale = 1.2f;
		if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0)
		{
			_modeFlag = PVE;
		}
	}
	else if (KeyMng::GetInstance().newKey[P1_LEFT])
	{
		box1._scale = 1.2f;
		if (KeyMng::GetInstance().trgKey[P1_SPACE])
		{
			_modeFlag = PVE;
		}
	}
	else
	{
		box1._scale = 1.0f;
	}
	if (mp._posX > box2._UL.x && mp._posY > box2._UL.y && mp._posX < box2._DR.x && mp._posY < box2._DR.y)
	{
		box2._scale = 1.2f;
		if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0)
		{
			//_modeFlag = SR;
		}
	}
	else if (KeyMng::GetInstance().newKey[P1_RIGHT])
	{
		box2._scale = 1.2f;

	}
	else
	{
		box2._scale = 1.0f;
	}
	if (mp._posX > box3._UL.x && mp._posY > box3._UL.y && mp._posX < box3._DR.x && mp._posY < box3._DR.y)
	{
		box3._scale = 1.0f;
		if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0)
		{
			_modeFlag = TITLE_SM;
		}
	}
	else if (KeyMng::GetInstance().newKey[P1_DOWN])
	{
		box3._scale = 1.0f;
		if (KeyMng::GetInstance().trgKey[P1_SPACE])
		{
			_modeFlag = TITLE_SM;
		}
	}
	else
	{
		box3._scale = 0.8f;
	}

	DrawRotaGraph(SCREEN_CENTER_X, 50, 1.1 , 0, IMAGE_ID("image/modesentaku.png"), true);
	DrawRotaGraph((box1._UL.x + box1._DR.x) / 2, (box1._UL.y + box1._DR.y) / 2, box1._scale, 0, IMAGE_ID("image/hitori.png"), true);
	DrawRotaGraph((box2._UL.x + box2._DR.x) / 2, (box2._UL.y + box2._DR.y) / 2, box2._scale, 0, IMAGE_ID("image/minna.png"), true);
	DrawRotaGraph((box2._UL.x + box2._DR.x) / 2, (box2._UL.y + box2._DR.y) / 2, box2._scale, (long float)-30 * (PI / 180), IMAGE_ID("image/coming.png"), true);
	DrawRotaGraph(SCREEN_SIZE_X - (SCREEN_CENTER_X / 4), SCREEN_SIZE_Y - 100, box3._scale, 0,IMAGE_ID("image/back.png"),true);
}
