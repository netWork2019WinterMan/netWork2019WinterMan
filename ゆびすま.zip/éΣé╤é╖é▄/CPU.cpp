#include "CPU.h"
#include "KeyMng.h"
#include "DxLib.h"


CPU::CPU(OYAKO oyako,PlayerType playertype, int playerNumber): _playertype(playertype)
{
	_finger._oyako = oyako;
	_finger._playerNumber = playerNumber;
}

CPU::CPU()
{
}

CPU::~CPU()
{
}

void CPU::Update()
{

	if (_changeFlag || GameMain::GetInstance().GetNowPlayer() <= 1)
	{
		return;
	}

	_nextFlag = false;
	auto nextNumber = GameMain::GetInstance().GetNextNumber();

	if (GameMain::GetInstance().GetStopMotion())
	{
		return;
	}

	if (_finger._playerNumber == nextNumber && _finger._nowNumber <= 0)
	{
		TurnNext();
		return;
	}
	if (GameMain::GetInstance().GetNextNumber() == _finger._playerNumber)
	{
		int randomCount = GetRand(6);
		if (_finger._pushCount >= MAX_TIME)
		{
			_nextFlag = true;
		}
		if (randomCount <= 5)
		{
			(_finger._pushCount < MAX_TIME ? _finger._pushCount++ : 0);
		}
		else
		{
			(_finger._pushCount > 0 ? _finger._pushCount-- : 0);
		}

		_finger._setValue = GetRand(GameMain::GetInstance().GetFingerValue());
	}

	if (_finger._nowNumber > 0)
	{
		_finger._number = GetRand(2);
	}
	else
	{
		_finger._number = 0;
	}
}

void CPU::Draw()
{
	auto& nextNumber = GameMain::GetInstance().GetNextNumber();
	if (_finger._oyako == OYAKO::OYA)
	{
		DrawString(100, 100, "OYA_Player", 0x000000);
	}
	else
	{
		DrawString(300, 100, "KO_Player", 0x000000);
	}

	if (_finger._playerNumber == nextNumber)
	{
		DrawBox(95 + (50 * nextNumber), 245, 130 + (50 * nextNumber), 305, 0xff0000, true);
		DrawFormatString(100 + (50 * nextNumber), 200, 0x000000, "%d", _finger._setValue);
		DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - _finger._pushCount, 0x00ffff, true);
		DrawBox(100 + (50 * nextNumber), 200, 120 + (50 * nextNumber), 200 - MAX_TIME, 0x000000, false);
	}
	DrawBox(100 + (50 * _finger._playerNumber), 250, 125 + (50 * _finger._playerNumber), 300, 0xffff00, true);

	DrawFormatString(100 + (50 * _finger._playerNumber), 230, 0x000000, "�w:%d", _finger._number);
	DrawFormatString(100 + (50 * _finger._playerNumber), 310, 0x000000, "��:%d", _finger._nowNumber);

	DrawFormatString(600, 400, 0x000000, "%d", nextNumber);
}

void CPU::ValueComparison()
{
	if (GetRand(2) == 0)
	{
		_waitTime++;
	}
	if ((KeyMng::GetInstance().trgKey[P1_ENTER] || _waitTime > 30) && _changeFlag)
	{
		KeyMng::GetInstance().trgKey[P1_ENTER] = false;
		_waitTime = 0;
		TurnNext();
	}
	/* �w�肵���w�̑����ƍ��v�l�������Ȃ�� */
	else if (_finger._nowNumber > 0 && !_changeFlag)
	{
		auto fingerValue = GameMain::GetInstance().GetNumberValue();

		if (_finger._setValue == fingerValue)
		{
			--_finger._nowNumber;
			if (_finger._nowNumber <= 0)
			{
				GameMain::GetInstance().SubPlayerNumber(1);
			}
		}
		_changeFlag = true;

	}
}

void CPU::TurnNext()
{
	auto nextNumber = GameMain::GetInstance().GetNextNumber();
	GameMain::GetInstance().SetStopMotion(false);
	GameMain::GetInstance().SetNextNumber((nextNumber >= GameMain::GetInstance().GetGameRule()._playerMax ? 1 : _finger._playerNumber + 1));
	_finger._setValue = 0;
	_finger._pushCount = 0;
	_changeFlag = false;

}

const int& CPU::GetNumber()
{
	return _finger._number;
}

const int& CPU::GetFingerNumber()
{
	return _finger._nowNumber;
}

const int& CPU::GetFingerValue()
{
	return _finger._setValue;
}

const bool& CPU::GetNextFlag()
{
	return _nextFlag;
}

const PlayerType& CPU::GetPlayerType()
{
	return _playertype;
}