#include <iostream>
#include <vector>
#include "DxLib.h"
#include "GameTask.h"
#include "KeyMng.h"
#include "MouseMng.h"
#include "ImageMng.h"
#include "TitleControl.h"
#include "ControlSelectMode.h"
#include "ControlGameResult.h"
#include "GameMain.h"


using namespace std;

GameTask *GameTask::s_Instance = nullptr;

void GameTask::Create(void)
{
	if (!s_Instance)
	{
		s_Instance = new GameTask();
	}
}

int GameTask::SystemInit()
{
	SetWindowText("YubisumaFighters(��)");
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);
	ChangeWindowMode(true);
	if (DxLib_Init() == -1) {
		return -1;
	}
	SetDrawScreen(DX_SCREEN_BACK);

	return 0;
}

void GameTask::GameUpdate()
{
	KeyMng::GetInstance().Update();
	MouseMng::GetInstance().Update();
	// ���݂̃��[�h�ŉ�
	(this->*gMode[_currentMode])();
}

void GameTask::GameInit()
{
	DrawString(10, 10, "INIT", 0x000000);

	//--------------------------------------------------
	// ������
	//--------------------------------------------------
	_currentMode = G_INIT;

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------

	// �^�C�g���ֈڍs
	if (_oldMode != G_RESULT)
	{
		_currentMode = G_TITLE;
	}
	// ���C���ֈڍs(���U���g����̃��g���C��)
	else
	{
		if (_futureMode == G_MAIN)
		{
			_currentMode = G_MAIN;
		}
		else if (_futureMode == G_SELECT_ROOM)
		{
			_currentMode = G_SELECT_ROOM;
		}
		else if (_futureMode == G_SELECT_MODE)
		{
			_currentMode = G_SELECT_MODE;
		}
	}
}

void GameTask::GameTitle()
{
	//--------------------------------------------------
	// ��ʕ`�揈��
	//--------------------------------------------------
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xf0f0f0, true);
	DrawString(10, 10, "TITLE", 0x000000);
	DrawString(10, 30, "SPACE->MODESELECT", 0x000000);

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------
	if (TitleControl::GetModeFlag())
	{
		_oldMode = _currentMode;
		_currentMode = G_SELECT_MODE;
		TitleControl::SetModeFlag(false);
	}

	//--------------------------------------------------
	// ����
	//--------------------------------------------------
	if (_createTimer % 50 == 0 || _createTimer == 0)
	{
		for (int i = 0; i < 20; i++)
		{
			tc.push_back(make_shared<TitleControl>());
		}
	}
	_createTimer++;

	//--------------------------------------------------
	// �X�V�A�`��
	//--------------------------------------------------
	auto itr = tc.begin();
	while (itr != tc.end())
	{
		(*itr)->Update();
		(*itr)->Draw();

		//--------------------------------------------------
		// ����
		//--------------------------------------------------
		if ((*itr)->GetHandRemove())
		{
			(*itr)->SetHandRemove(false);
			itr = tc.erase(itr,itr + 20);
		}
		else
		{
			itr++;
		}
	}
	DrawRotaGraph(SCREEN_CENTER_X, SCREEN_CENTER_Y, 1.0, 0, IMAGE_ID("image/yubisumafighters.png"), true);
}


void GameTask::GameSelectMode()
{
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xf0f0f0, true);

	DrawString(10, 10, "MODE SELECT", 0x000000);
	DrawString(10, 30, "SPACE->MAIN", 0x000000);
	DrawString(10, 50, "ENTER->ROOMSELECT", 0x000000);

	if (csm.empty())
	{
		csm.push_back(make_shared<ControlSelectMode>());
	}

	for (auto itr : csm)
	{
		(*itr).Update();
		(*itr).Draw();

		//--------------------------------------------------
		// ��ʑJ�ڏ���
		//--------------------------------------------------

		if ((*itr).GetModeFlag() == PVE)
		{
			_oldMode = _currentMode;
			_currentMode = G_RULE;
			(*itr).SetModeFlag(NON_SM);
		}
		if ((*itr).GetModeFlag() == TITLE_SM)
		{
			_oldMode = _currentMode;
			_currentMode = G_TITLE;
			(*itr).SetModeFlag(NON_SM);
		}

		//if ((*itr).GetModeFlag() == SR)
		//{
		//	_oldMode = _currentMode;
		//	_currentMode = G_SELECT_ROOM;
		//	(*itr).SetModeFlag(NON);
		//}
	}
}

// coming soon...
void GameTask::GameSelectRoom()
{
	DrawString(10, 10, "ROOM SELECT", 0x000000);
	DrawString(10, 30, "SPACE->MAIN", 0x000000);

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------

	// �Q�[�����C��(PvP)�ֈڍs
	if (KeyMng::GetInstance().trgKey[P1_SPACE])
	{
		_oldMode = _currentMode;
		_currentMode = G_MAIN;
	}
}

void GameTask::GameRule()
{
	float size = 1.0f;

	GetMousePoint(&_rule._x, &_rule._y);

	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xf0f0f0, true);
	DrawString(10, 10, "RULE", 0x000000);

	DrawFormatString(100, 150, 0x000000, "�l��:%d", _rule._playerMax);

	if (MouseMng::GetInstance().trgKey[P1_PUSH])
	{
		if ((_rule._x > 100 && _rule._x < 160) && (_rule._y > 150 && _rule._y < 170))
		{
			_rule._playerMax++;
		}
	}
	else if (KeyMng::GetInstance().trgKey[P1_RIGHT])
	{
		(_rule._playerMax < MAX_PLAYER ? _rule._playerMax++ : 0);
	}
	else if (KeyMng::GetInstance().trgKey[P1_LEFT])
	{
		(_rule._playerMax > 0 ? _rule._playerMax-- : 0);
	}

	if ((_rule._x > SCREEN_CENTER_X - (290 / 2) && _rule._x < SCREEN_CENTER_X + (290 / 2)) &&
		(_rule._y > (SCREEN_CENTER_Y + SCREEN_CENTER_Y / 2) - (100 / 2) && _rule._y < (SCREEN_CENTER_Y + SCREEN_CENTER_Y / 2) + (100 / 2)))
	{
		size = 1.2f;

		if (MouseMng::GetInstance().trgKey[P1_PUSH])
		{
			GameMain::GetInstance().SetGameRule(_rule);
			_oldMode = _currentMode;
			_currentMode = G_MAIN;
		}
	}
	else if (KeyMng::GetInstance().newKey[P1_DOWN])
	{
		size = 1.2f;
		if (KeyMng::GetInstance().trgKey[P1_SPACE])
		{
			GameMain::GetInstance().SetGameRule(_rule);
			_oldMode = _currentMode;
			_currentMode = G_MAIN;
		}
	}

	for (int i = 0; i < _rule._playerMax; ++i)
	{
		DrawBox(95 + (50 * (i % 5)), 195 + (50 * (i / 5)), 130 + (50 * (i % 5)), 235 + (50 * (i / 5)), 0xff0000, true);
		DrawRotaGraph(95 + (50 * (i % 5)), 195 + (50 * (i / 5)), 1.0, 0.0, IMAGE_ID("image/Gj_hand.png"), true);
	}
	DrawRotaGraph(SCREEN_CENTER_X, SCREEN_CENTER_Y + SCREEN_CENTER_Y / 2, size, 0.0, IMAGE_ID("image/start.png"), true);

}

void GameTask::GameMain()
{
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xf0f0f0, true);
	DrawString(10, 10, "MAIN", 0x000000);
	DrawString(10, 30, "SPACE->RESULT", 0x000000);

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------
	GameMain::GetInstance().Run();

	auto playerNumber = GameMain::GetInstance().GetNowPlayer();
	// ���U���g�ֈڍs
	if (KeyMng::GetInstance().trgKey[P1_SPACE] || playerNumber <= 1)
	{
		GameMain::GetInstance().Clear();
		GameMain::GetInstance().SetNowPlayer(GameMain::GetInstance().GetGameRule()._playerMax);
		_oldMode = _currentMode;
		_currentMode = G_RESULT;
	}
}

void GameTask::GameResult()
{
	DrawBox(0, 0, SCREEN_SIZE_X, SCREEN_SIZE_Y, 0xf0f0f0, true);
	DrawString(10, 10, "RESULT", 0x000000);
	DrawString(10, 30, "SPACE->MAIN", 0x000000);
	DrawString(10, 50, "ENTER->ROOMSELECT", 0x000000);
	DrawString(10, 70, "LCtrl->MODESELECT", 0x000000);

	if (cgr.empty())
	{
		cgr.push_back(make_shared<ControlGameResult>());
	}

	for (auto itr : cgr)
	{
		(*itr).Update();
		(*itr).Draw();

		//--------------------------------------------------
		// ��ʑJ�ڏ���
		//--------------------------------------------------

		if ((*itr).GetModeFlag() == MAIN)
		{
			_oldMode = _currentMode;
			_futureMode = G_MAIN;
			_currentMode = G_MAIN;
			(*itr).SetModeFlag(NON_RE);
		}
		if ((*itr).GetModeFlag() == SM)
		{
			_oldMode = _currentMode;
			_futureMode = G_SELECT_MODE;
			_currentMode = G_INIT;
			(*itr).SetModeFlag(NON_RE);
		}
	}

	//--------------------------------------------------
	// ��ʑJ�ڏ���
	//--------------------------------------------------

	// coming soon...
	// ���[���Z���N�g�ֈڍs(PvP�̂�)
	//if (KeyMng::GetInstance().trgKey[P1_ENTER])
	//{
	//	_oldMode = _currentMode;
	//	_futureMode = G_SELECT_ROOM;
	//	_currentMode = G_INIT;
	//}
}
